import React, { useState, useEffect } from 'react';
import { 
  Globe, 
  Search, 
  TrendingUp, 
  TrendingDown, 
  Activity, 
  Layers, 
  AlertCircle, 
  Settings, 
  FileText, 
  Download, 
  Plus, 
  Check, 
  CheckCircle2, 
  ArrowRight, 
  ChevronRight, 
  ChevronDown, 
  Database, 
  LineChart, 
  ExternalLink, 
  Eye, 
  CheckSquare, 
  RefreshCw, 
  SlidersHorizontal, 
  Cpu, 
  Award, 
  HelpCircle, 
  FileDown, 
  Copy, 
  PlusCircle, 
  Edit,
  Sparkles,
  Zap,
  CheckCircle,
  AlertTriangle,
  FileCode,
  Share2,
  Trash2,
  Lock,
  MapPin,
  Calendar,
  User
} from 'lucide-react';
import { AnalysisResponse, KeywordItem, TopicCluster, ContentGapItem, RecommendationItem, ContentGenerationResponse, ContentEnhanceResponse } from './types';

// Preset configurations for easy 1-click testing
const PRESETS = [
  {
    name: "SaaS CRM Platform (e.g., HubSpot)",
    selfUrl: "https://hubspot.com",
    competitorA: "https://salesforce.com",
    competitorB: "https://zoho.com"
  },
  {
    name: "Fintech & Subscriptions (e.g., Stripe)",
    selfUrl: "https://stripe.com",
    competitorA: "https://paypal.com",
    competitorB: "https://adyen.com"
  },
  {
    name: "E-Commerce Retailer (e.g., Shopify)",
    selfUrl: "https://shopify.com",
    competitorA: "https://bigcommerce.com",
    competitorB: "https://woocommerce.com"
  }
];

export default function App() {
  // Login and Session states
  const [isLoggedIn, setIsLoggedIn] = useState(() => localStorage.getItem('cluster_plus_logged_in') === 'true');
  const [loginUserId, setLoginUserId] = useState('');
  const [loginPassword, setLoginPassword] = useState('');
  const [loginError, setLoginError] = useState<string | null>(null);

  // Input fields
  const [selfUrl, setSelfUrl] = useState('');
  const [competitorA, setCompetitorA] = useState('');
  const [competitorB, setCompetitorB] = useState('');
  
  // Location and Date duration targets
  const [location, setLocation] = useState('United States');
  const [duration, setDuration] = useState('Last 30 Days');
  const [dataSource, setDataSource] = useState<'DataForSEO' | 'GSC'>('DataForSEO');
  
  // Google Search Console link and file upload states
  const [gscLinkOrId, setGscLinkOrId] = useState('');
  const [gscFileConnected, setGscFileConnected] = useState(false);
  const [gscFileName, setGscFileName] = useState('');

  // DataForSEO Sandbox configuration credentials
  const [dfseoSandboxLogin, setDfseoSandboxLogin] = useState('admin@dataforseo.com');
  const [dfseoSandboxPassword, setDfseoSandboxPassword] = useState('••••••••••••••••••••');
  const [isTestingConnection, setIsTestingConnection] = useState(false);
  const [connectionTestSuccess, setConnectionTestSuccess] = useState<string | null>(null);
  const [connectionTestError, setConnectionTestError] = useState<string | null>(null);

  // Snapshot list and active snapshot state
  const [snapshots, setSnapshots] = useState<any[]>([]);
  const [activeSnapshotId, setActiveSnapshotId] = useState<string | null>(null);

  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analysisError, setAnalysisError] = useState<string | null>(null);

  // Analysis Result
  const [result, setResult] = useState<AnalysisResponse | null>(null);

  // Dashboards Tabs
  // 'overview' | 'keywords' | 'clusters' | 'competitors' | 'gaps' | 'recommendations' | 'studio' | 'reports' | 'alerts' | 'settings'
  const [activeTab, setActiveTab] = useState<string>('overview');

  // Filters for Keyword Dashboard
  const [kwSearch, setKwSearch] = useState('');
  const [kwIntentFilter, setKwIntentFilter] = useState<string>('all');
  const [kwDifficultyFilter, setKwDifficultyFilter] = useState<string>('all');
  const [kwPositionFilter, setKwPositionFilter] = useState<string>('all');

  // Selected Cluster for Topic Cluster Detail Panel
  const [selectedClusterId, setSelectedClusterId] = useState<string | null>(null);

  // Content Generation Studio State
  const [genTopic, setGenTopic] = useState('');
  const [genType, setGenType] = useState<'Blog' | 'Landing Page' | 'FAQ' | 'Comparison Page' | 'Product Description'>('Blog');
  const [genKeywords, setGenKeywords] = useState<string[]>([]);
  const [newKeywordInput, setNewKeywordInput] = useState('');
  const [genTone, setGenTone] = useState('Professional & Authoritative');
  const [genInstructions, setGenInstructions] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [genResult, setGenResult] = useState<ContentGenerationResponse | null>(null);
  const [studioMode, setStudioMode] = useState<'create' | 'enhance'>('create');

  // Content Enhancement Studio State
  const [enhanceUrl, setEnhanceUrl] = useState('');
  const [existingContent, setExistingContent] = useState('');
  const [isEnhancing, setIsEnhancing] = useState(false);
  const [enhanceResult, setEnhanceResult] = useState<ContentEnhanceResponse | null>(null);

  // Copy/Export notifications
  const [copyNotification, setCopyNotification] = useState<string | null>(null);
  const [exportNotification, setExportNotification] = useState<string | null>(null);

  // Active Alerts state
  const [alerts, setAlerts] = useState<Array<{ id: string; type: 'warning' | 'success' | 'info'; title: string; desc: string; time: string }>>([
    { id: '1', type: 'info', title: 'New Content Gap Detected', desc: 'Competitor A has created a new high-performing landing page targeting "developer analytics templates" with 1.2k volume.', time: '10 mins ago' },
    { id: '2', type: 'warning', title: 'Position Drop Alert', desc: 'Self URL fell out of the top 3 spots for "analytics dashboards" to rank 7th.', time: '2 hours ago' },
    { id: '3', type: 'success', title: 'Organic Position Gain', desc: 'Your article on "billing systems architectures" entered the top 5 for "automated billing platform" search queries.', time: '5 hours ago' },
    { id: '4', type: 'info', title: 'Competitor A Landing Page Update', desc: 'Competitor A added 4 new FAQ question blocks with schema markup on their main pricing page.', time: '1 day ago' },
  ]);

  // Load a preset for testing
  const handleLoadPreset = (preset: typeof PRESETS[0]) => {
    setSelfUrl(preset.selfUrl);
    setCompetitorA(preset.competitorA);
    setCompetitorB(preset.competitorB);
  };

  // Perform secure login via backend API
  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoginError(null);
    if (!loginUserId || !loginPassword) {
      setLoginError("Please enter your User ID and Password.");
      return;
    }

    try {
      const response = await fetch('/api/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username: loginUserId, password: loginPassword }),
      });

      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        throw new Error(errorData.error || 'Invalid User ID or Password.');
      }

      const data = await response.json();
      if (data.success) {
        setIsLoggedIn(true);
        localStorage.setItem('cluster_plus_logged_in', 'true');
      }
    } catch (err: any) {
      setLoginError(err.message || 'Login request failed.');
    }
  };

  // Handle Logout
  const handleLogout = () => {
    setIsLoggedIn(false);
    localStorage.removeItem('cluster_plus_logged_in');
    setResult(null);
    setLoginUserId('');
    setLoginPassword('');
    setLoginError(null);
  };

  // Handle Testing DataForSEO Sandbox Connection
  const handleTestConnection = async () => {
    setIsTestingConnection(true);
    setConnectionTestSuccess(null);
    setConnectionTestError(null);

    try {
      const response = await fetch('/api/test-connection', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ login: dfseoSandboxLogin, password: dfseoSandboxPassword }),
      });

      if (!response.ok) {
        const errData = await response.json().catch(() => ({}));
        throw new Error(errData.error || 'Connection authentication failed.');
      }

      const data = await response.json();
      if (data.success) {
        setConnectionTestSuccess(data.message);
      }
    } catch (err: any) {
      setConnectionTestError(err.message || 'Failed to authenticate connection.');
    } finally {
      setIsTestingConnection(false);
    }
  };

  // Run the analysis API
  const handleAnalyze = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!selfUrl || !competitorA || !competitorB) {
      setAnalysisError("Please fill in your website and both competitor domains.");
      return;
    }

    setIsAnalyzing(true);
    setAnalysisError(null);

    try {
      const response = await fetch('/api/analyze', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          selfUrl, 
          competitorA, 
          competitorB, 
          location,
          duration, 
          dataSource,
          gscLinkOrId,
          gscFileConnected
        }),
      });

      if (!response.ok) {
        throw new Error('Analysis failed. Please check your network and try again.');
      }

      const data = await response.json();
      if (data.current) {
        setResult(data.current);
        setSnapshots(data.all || []);
        setActiveSnapshotId(data.current.id);
        
        if (data.current.clusters && data.current.clusters.length > 0) {
          setSelectedClusterId(data.current.clusters[0].id);
        }
      } else {
        setResult(data);
        if (data.clusters && data.clusters.length > 0) {
          setSelectedClusterId(data.clusters[0].id);
        }
      }
      setActiveTab('overview');
    } catch (err: any) {
      setAnalysisError(err.message || 'An error occurred during domain parsing.');
    } finally {
      setIsAnalyzing(false);
    }
  };

  // Select active snapshot from timeline
  const handleSelectSnapshot = (snapshotId: string) => {
    const found = snapshots.find(s => s.id === snapshotId);
    if (found) {
      setResult(found);
      setActiveSnapshotId(snapshotId);
      if (found.clusters && found.clusters.length > 0) {
        setSelectedClusterId(found.clusters[0].id);
      }
    }
  };

  // Trigger content generation
  const handleGenerateContent = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!genTopic) return;

    setIsGenerating(true);
    try {
      const response = await fetch('/api/generate-content', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          topic: genTopic,
          type: genType,
          keywords: genKeywords,
          tone: genTone,
          additionalInstructions: genInstructions
        }),
      });

      if (!response.ok) throw new Error('Generation failed.');
      const data: ContentGenerationResponse = await response.json();
      setGenResult(data);
    } catch (err) {
      alert('Failed to generate content. Please try again.');
    } finally {
      setIsGenerating(false);
    }
  };

  // Trigger content enhance audit
  const handleEnhanceContent = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!existingContent) return;

    setIsEnhancing(true);
    try {
      const response = await fetch('/api/enhance-content', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          url: enhanceUrl,
          existingContent
        }),
      });

      if (!response.ok) throw new Error('Audit failed.');
      const data: ContentEnhanceResponse = await response.json();
      setEnhanceResult(data);
    } catch (err) {
      alert('Failed to analyze existing content. Please try again.');
    } finally {
      setIsEnhancing(false);
    }
  };

  // Quick pre-populate generation from a recommendation or a gap
  const handleQuickWrite = (title: string, clusterKeywords: string[] = []) => {
    setGenTopic(title);
    setGenKeywords(clusterKeywords.length > 0 ? clusterKeywords : [title]);
    setStudioMode('create');
    setActiveTab('studio');
    setGenResult(null);
  };

  // Export report down
  const handleExportReport = async (format: 'MD' | 'CSV') => {
    if (!result) return;
    setExportNotification(`Preparing ${format} download...`);

    if (format === 'MD') {
      try {
        const response = await fetch('/api/reports/download', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ data: result }),
        });
        if (response.ok) {
          const blob = await response.blob();
          const url = window.URL.createObjectURL(blob);
          const a = document.createElement('a');
          a.href = url;
          a.download = `SEO_Report_${result.selfUrl.replace(/[^a-zA-Z0-9]/g, '_')}.md`;
          document.body.appendChild(a);
          a.click();
          a.remove();
        }
      } catch (e) {
        alert('Failed to download report.');
      }
    } else {
      // Create simple simulated CSV for Keywords
      let csvContent = "data:text/csv;charset=utf-8,";
      csvContent += "Keyword,Cluster,Search Volume,Difficulty %,Position Self,Position Comp A,Position Comp B,Intent\n";
      result.keywords.forEach(k => {
        csvContent += `"${k.keyword}","${k.cluster}",${k.volume},${k.difficulty},${k.positionSelf || 'N/A'},${k.positionCompA || 'N/A'},${k.positionCompB || 'N/A'},"${k.intent}"\n`;
      });
      const encodedUri = encodeURI(csvContent);
      const link = document.createElement("a");
      link.setAttribute("href", encodedUri);
      link.setAttribute("download", "seo_keywords_gap_export.csv");
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    }

    setTimeout(() => setExportNotification(null), 3000);
  };

  // Copy helper
  const handleCopyToClipboard = (text: string, label: string) => {
    navigator.clipboard.writeText(text);
    setCopyNotification(`Copied ${label} to clipboard!`);
    setTimeout(() => setCopyNotification(null), 3000);
  };

  // Trigger simulated keyword add
  const handleAddKeyword = () => {
    if (newKeywordInput.trim() && !genKeywords.includes(newKeywordInput.trim())) {
      setGenKeywords([...genKeywords, newKeywordInput.trim()]);
      setNewKeywordInput('');
    }
  };

  // Remove targeted keyword
  const handleRemoveKeyword = (index: number) => {
    setGenKeywords(genKeywords.filter((_, idx) => idx !== index));
  };

  // Keyword dashboard logic
  const filteredKeywords = result ? result.keywords.filter(k => {
    const matchSearch = k.keyword.toLowerCase().includes(kwSearch.toLowerCase()) || k.cluster.toLowerCase().includes(kwSearch.toLowerCase());
    const matchIntent = kwIntentFilter === 'all' || k.intent.toLowerCase() === kwIntentFilter.toLowerCase();
    
    let matchDiff = true;
    if (kwDifficultyFilter === 'easy') matchDiff = k.difficulty < 40;
    else if (kwDifficultyFilter === 'medium') matchDiff = k.difficulty >= 40 && k.difficulty <= 65;
    else if (kwDifficultyFilter === 'hard') matchDiff = k.difficulty > 65;

    // Filter to only keywords where self rank is worse/lower than competitors rank
    // Lower rank means positionSelf is larger than competitor rank (lower on the page) or positionSelf is 0 (not ranking) while a competitor ranks
    const isSelfRankLower = 
      (k.positionCompA > 0 && (k.positionSelf === 0 || k.positionSelf > k.positionCompA)) || 
      (k.positionCompB > 0 && (k.positionSelf === 0 || k.positionSelf > k.positionCompB));

    return matchSearch && matchIntent && matchDiff && isSelfRankLower;
  }) : [];

  const selectedCluster = result?.clusters.find(c => c.id === selectedClusterId);

  // Draw a beautiful custom SVG chart showing Topical Authority score and Total Keywords over past snapshots
  const renderTrendsChart = () => {
    if (!snapshots || snapshots.length < 2) {
      return (
        <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm flex flex-col items-center justify-center min-h-[220px]">
          <LineChart className="h-8 w-8 text-slate-300 animate-bounce" />
          <span className="text-xs font-bold text-slate-500 mt-2">Generate snapshotted data to render timelines</span>
          <p className="text-[10px] text-slate-400">Add URLs and click Generate above to build historical views.</p>
        </div>
      );
    }

    // Sort snapshots chronologically (older first)
    const sortedSnaps = [...snapshots].reverse();
    const width = 500;
    const height = 150;
    const padding = 30;

    // Calculate coordinates for points
    const points = sortedSnaps.map((snap, idx) => {
      const x = padding + (idx / (sortedSnaps.length - 1)) * (width - padding * 2);
      // Health score ranges 0 to 100
      const score = snap.overview?.contentHealthScore || 70;
      const y = height - padding - (score / 100) * (height - padding * 2);
      return { x, y, score, date: snap.timestamp };
    });

    // Build SVG path
    let pathD = `M ${points[0].x} ${points[0].y}`;
    for (let i = 1; i < points.length; i++) {
      pathD += ` L ${points[i].x} ${points[i].y}`;
    }

    return (
      <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm space-y-4">
        <div className="flex justify-between items-center">
          <div>
            <h3 className="text-sm font-bold text-slate-900">Topical Authority Trend Timeline</h3>
            <p className="text-[10px] text-slate-400 font-medium">Content Health Score tracked across historical runs</p>
          </div>
          <span className="text-[10px] font-extrabold text-indigo-600 bg-indigo-50 px-2.5 py-1 rounded-full uppercase tracking-wider">
            Historic Series
          </span>
        </div>

        <div className="relative pt-2">
          <svg viewBox={`0 0 ${width} ${height}`} className="w-full h-auto overflow-visible">
            {/* Gridlines */}
            <line x1={padding} y1={padding} x2={width - padding} y2={padding} stroke="#f1f5f9" strokeWidth="1" />
            <line x1={padding} y1={height / 2} x2={width - padding} y2={height / 2} stroke="#f1f5f9" strokeWidth="1" />
            <line x1={padding} y1={height - padding} x2={width - padding} y2={height - padding} stroke="#f8fafc" strokeWidth="1.5" />

            {/* Area Path under the line for gorgeous gradient */}
            <path
              d={`${pathD} L ${points[points.length - 1].x} ${height - padding} L ${points[0].x} ${height - padding} Z`}
              fill="url(#trendGradient)"
              opacity="0.15"
            />

            {/* Main Trend Line */}
            <path d={pathD} fill="none" stroke="#4f46e5" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" />

            {/* Data Dots */}
            {points.map((pt, idx) => (
              <g key={idx} className="group cursor-pointer">
                <circle
                  cx={pt.x}
                  cy={pt.y}
                  r="4"
                  fill="#ffffff"
                  stroke="#4f46e5"
                  strokeWidth="2.5"
                  className="transition transform hover:scale-150"
                />
                {/* Text Indicator on Dot */}
                <text
                  x={pt.x}
                  y={pt.y - 10}
                  textAnchor="middle"
                  fill="#1e293b"
                  fontSize="8"
                  fontWeight="bold"
                >
                  {pt.score}%
                </text>
                {/* X axis labels */}
                <text
                  x={pt.x}
                  y={height - 10}
                  textAnchor="middle"
                  fill="#94a3b8"
                  fontSize="7"
                  fontWeight="bold"
                >
                  {pt.date.split(',')[0]}
                </text>
              </g>
            ))}

            {/* Definitions for gradient */}
            <defs>
              <linearGradient id="trendGradient" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="#4f46e5" />
                <stop offset="100%" stopColor="#4f46e5" stopOpacity="0" />
              </linearGradient>
            </defs>
          </svg>
        </div>
      </div>
    );
  };

  return (
    <div className="min-h-screen bg-slate-50 text-slate-800 flex flex-col font-sans">
      {/* GLOBAL TOAST NOTIFICATIONS */}
      {copyNotification && (
        <div className="fixed bottom-6 right-6 z-50 bg-emerald-600 text-white px-4 py-3 rounded-lg shadow-xl flex items-center gap-2 animate-bounce">
          <Check className="h-5 w-5" />
          <span className="font-medium text-sm">{copyNotification}</span>
        </div>
      )}
      {exportNotification && (
        <div className="fixed bottom-6 right-6 z-50 bg-blue-600 text-white px-4 py-3 rounded-lg shadow-xl flex items-center gap-2">
          <RefreshCw className="h-5 w-5 animate-spin" />
          <span className="font-medium text-sm">{exportNotification}</span>
        </div>
      )}

      {/* HEADER BAR */}
      <header className="bg-white border-b border-slate-200 sticky top-0 z-40 px-6 py-4 flex items-center justify-between shadow-sm">
        <div className="flex items-center gap-3">
          <div className="bg-indigo-600 text-white p-2 rounded-lg">
            <Sparkles className="h-6 w-6" />
          </div>
          <div>
            <h1 className="text-xl font-bold tracking-tight text-slate-900">Cluster+</h1>
            <p className="text-xs text-slate-500 font-medium">Enterprise Content Gap Intelligence Platform</p>
          </div>
        </div>

        <div className="flex items-center gap-3">
          {result && (
            <div className="hidden lg:flex items-center gap-4 bg-slate-100 px-4 py-2 rounded-xl">
              <div className="text-xs font-semibold text-slate-600 flex items-center gap-1.5">
                <Globe className="h-4 w-4 text-indigo-500" />
                <span className="max-w-[120px] truncate">{result.selfUrl.replace(/^(https?:\/\/)?(www\.)?/, '')}</span>
              </div>
              <div className="text-xs text-slate-400 font-bold">VS</div>
              <div className="text-xs font-semibold text-slate-600 max-w-[120px] truncate">
                {result.competitorA.replace(/^(https?:\/\/)?(www\.)?/, '')}
              </div>
              <div className="text-xs font-semibold text-slate-600 max-w-[120px] truncate">
                {result.competitorB.replace(/^(https?:\/\/)?(www\.)?/, '')}
              </div>
              <button 
                onClick={() => { setResult(null); setActiveTab('overview'); }}
                className="ml-2 text-xs text-rose-600 font-bold hover:underline cursor-pointer"
              >
                Reset
              </button>
            </div>
          )}

          {isLoggedIn && (
            <button
              onClick={handleLogout}
              className="px-4 py-2 bg-slate-100 hover:bg-rose-50 hover:text-rose-600 text-slate-700 rounded-xl text-xs font-bold transition cursor-pointer"
            >
              Sign Out
            </button>
          )}
        </div>
      </header>

      {/* MAIN CONTENT AREA */}
      {!isLoggedIn ? (
        // PAGE 1: LOGIN PAGE
        <main className="flex-1 flex flex-col items-center justify-center px-6 py-12 bg-slate-50 animate-fade-in">
          <div className="w-full max-w-md bg-white rounded-3xl border border-slate-200 shadow-xl overflow-hidden p-8 space-y-6">
            <div className="text-center space-y-2">
              <div className="mx-auto w-12 h-12 bg-indigo-600 text-white rounded-xl flex items-center justify-center shadow-md">
                <Sparkles className="h-6 w-6" />
              </div>
              <h2 className="text-3xl font-extrabold tracking-tight text-slate-900">Cluster+</h2>
              <p className="text-xs text-slate-500 font-semibold uppercase tracking-widest">Enterprise Content Intelligence</p>
            </div>

            <form onSubmit={handleLogin} className="space-y-4">
              {loginError && (
                <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-xl text-xs flex items-center gap-2">
                  <AlertCircle className="h-4.5 w-4.5 text-red-500 shrink-0" />
                  <span>{loginError}</span>
                </div>
              )}

              <div className="space-y-1.5">
                <label className="text-xs font-bold text-slate-700 block">User ID</label>
                <div className="relative">
                  <User className="absolute left-3.5 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
                  <input
                    type="text"
                    placeholder="Enter User ID"
                    value={loginUserId}
                    onChange={(e) => setLoginUserId(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl pl-10 pr-4 py-2.5 text-sm outline-none focus:bg-white focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 transition"
                    required
                  />
                </div>
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-bold text-slate-700 block">Password</label>
                <div className="relative">
                  <Lock className="absolute left-3.5 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
                  <input
                    type="password"
                    placeholder="Enter Password"
                    value={loginPassword}
                    onChange={(e) => setLoginPassword(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl pl-10 pr-4 py-2.5 text-sm outline-none focus:bg-white focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 transition"
                    required
                  />
                </div>
              </div>

              <button
                type="submit"
                className="w-full py-3 bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded-xl shadow-lg shadow-indigo-500/10 flex items-center justify-center gap-2 transition cursor-pointer"
              >
                <span>Log In</span>
                <ArrowRight className="h-4 w-4" />
              </button>
            </form>

            <div className="text-center pt-2">
              <span className="text-[10px] text-slate-400 font-semibold block">Configured accounts managed securely via configuration.</span>
            </div>
          </div>
        </main>
      ) : !result ? (
        // PAGE 2: LANDING / INGESTION PAGE
        <main className="flex-1 max-w-4xl w-full mx-auto px-6 py-12 flex flex-col justify-center animate-fade-in">
          <div className="bg-white rounded-3xl border border-slate-200 shadow-xl overflow-hidden">
            {/* Header visual branding */}
            <div className="bg-gradient-to-r from-indigo-600 via-indigo-700 to-slate-900 p-8 text-white relative">
              <div className="absolute top-0 right-0 p-8 opacity-10">
                <Layers className="w-48 h-48" />
              </div>
              <span className="bg-indigo-500/30 text-indigo-200 text-xs uppercase tracking-widest font-bold px-3 py-1 rounded-full border border-indigo-400/20">
                Enterprise Platform
              </span>
              <h2 className="text-3xl font-extrabold mt-4 tracking-tight">Compare Topic Clusters & Content Gaps</h2>
              <p className="text-indigo-100 text-sm mt-2 max-w-xl leading-relaxed">
                Connect your domains, choose a search index or search console integration, analyze intent-aligned keywords, and build a competitive gap matrix.
              </p>
            </div>

            {/* Config & Forms */}
            <form onSubmit={handleAnalyze} className="p-8 space-y-6">
              {analysisError && (
                <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-xl text-sm flex items-center gap-2">
                  <AlertCircle className="h-5 w-5 text-red-500 shrink-0" />
                  <span>{analysisError}</span>
                </div>
              )}

              {/* URL Ingestion */}
              <div className="space-y-1.5">
                <h3 className="text-sm font-bold text-slate-900">1. Domain Competitor Setup</h3>
                <p className="text-xs text-slate-500">Specify your primary domain and two close organic competitors for content analysis.</p>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="space-y-1.5">
                  <label htmlFor="selfUrl" className="text-xs font-bold text-slate-700 block">
                    Your Website URL
                  </label>
                  <div className="relative">
                    <Globe className="absolute left-3.5 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
                    <input
                      id="selfUrl"
                      type="url"
                      placeholder="https://mywebsite.com"
                      value={selfUrl}
                      onChange={(e) => setSelfUrl(e.target.value)}
                      className="w-full bg-slate-50 border border-slate-200 rounded-xl pl-10 pr-4 py-2.5 text-sm focus:bg-white focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 outline-none transition"
                      required
                    />
                  </div>
                </div>

                <div className="space-y-1.5">
                  <label htmlFor="competitorA" className="text-xs font-bold text-slate-700 block">
                    Competitor Website A
                  </label>
                  <div className="relative">
                    <Globe className="absolute left-3.5 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
                    <input
                      id="competitorA"
                      type="url"
                      placeholder="https://competitor-a.com"
                      value={competitorA}
                      onChange={(e) => setCompetitorA(e.target.value)}
                      className="w-full bg-slate-50 border border-slate-200 rounded-xl pl-10 pr-4 py-2.5 text-sm focus:bg-white focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 outline-none transition"
                      required
                    />
                  </div>
                </div>

                <div className="space-y-1.5">
                  <label htmlFor="competitorB" className="text-xs font-bold text-slate-700 block">
                    Competitor Website B
                  </label>
                  <div className="relative">
                    <Globe className="absolute left-3.5 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
                    <input
                      id="competitorB"
                      type="url"
                      placeholder="https://competitor-b.com"
                      value={competitorB}
                      onChange={(e) => setCompetitorB(e.target.value)}
                      className="w-full bg-slate-50 border border-slate-200 rounded-xl pl-10 pr-4 py-2.5 text-sm focus:bg-white focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 outline-none transition"
                      required
                    />
                  </div>
                </div>
              </div>

              {/* Data Source Segmented Control */}
              <div className="space-y-3 pt-4 border-t border-slate-100">
                <div className="grid grid-cols-2 p-1 bg-slate-100 rounded-xl max-w-md">
                  <button
                    type="button"
                    onClick={() => setDataSource('DataForSEO')}
                    className={`py-2 rounded-lg text-xs font-bold transition cursor-pointer ${
                      dataSource === 'DataForSEO' 
                        ? 'bg-white text-indigo-700 shadow-sm' 
                        : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    DataForSEO Index API
                  </button>
                  <button
                    type="button"
                    onClick={() => setDataSource('GSC')}
                    className={`py-2 rounded-lg text-xs font-bold transition cursor-pointer ${
                      dataSource === 'GSC' 
                        ? 'bg-white text-indigo-700 shadow-sm' 
                        : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    Google Search Console File/Link
                  </button>
                </div>

                {dataSource === 'DataForSEO' ? null : (
                  /* GSC Property & Drag-and-Drop Ingestion Block */
                  <div className="bg-indigo-50/50 border border-indigo-100 rounded-2xl p-5 space-y-4">
                    <div className="flex items-center gap-2">
                      <FileCode className="h-5 w-5 text-indigo-600" />
                      <span className="text-xs font-bold text-slate-800">Google Search Console Integration</span>
                    </div>

                    <div className="space-y-1.5">
                      <label className="text-[10px] font-bold text-slate-600 uppercase">GSC Property URL or View ID</label>
                      <input
                        type="text"
                        placeholder="sc-domain:mywebsite.com or https://mywebsite.com/"
                        value={gscLinkOrId}
                        onChange={(e) => setGscLinkOrId(e.target.value)}
                        className="w-full bg-white border border-slate-200 rounded-xl px-3 py-2.5 text-xs outline-none focus:border-indigo-500"
                      />
                    </div>

                    {/* Drag-and-Drop File Upload Area */}
                    <div className="space-y-1">
                      <label className="text-[10px] font-bold text-slate-600 uppercase">GSC Performance Query Export (CSV or JSON)</label>
                      <div
                        onDragOver={(e) => e.preventDefault()}
                        onDrop={(e) => {
                          e.preventDefault();
                          const file = e.dataTransfer.files[0];
                          if (file) {
                            setGscFileConnected(true);
                            setGscFileName(file.name);
                          }
                        }}
                        onClick={() => {
                          // Simulate immediate mock file attach
                          setGscFileConnected(true);
                          setGscFileName('gsc_organic_performance_export_' + new Date().toISOString().split('T')[0] + '.csv');
                        }}
                        className={`border-2 border-dashed rounded-xl p-6 text-center cursor-pointer transition ${
                          gscFileConnected 
                            ? 'border-emerald-400 bg-emerald-50/20' 
                            : 'border-indigo-200 bg-white hover:bg-slate-50 hover:border-indigo-400'
                        }`}
                      >
                        {gscFileConnected ? (
                          <div className="flex flex-col items-center gap-1">
                            <CheckCircle2 className="h-8 w-8 text-emerald-500" />
                            <span className="text-xs font-bold text-emerald-700">GSC Export File Connected Successfully!</span>
                            <span className="text-[10px] text-slate-500 font-mono">{gscFileName}</span>
                            <button
                              type="button"
                              onClick={(e) => {
                                e.stopPropagation();
                                setGscFileConnected(false);
                                setGscFileName('');
                              }}
                              className="mt-1 text-[10px] text-rose-500 hover:underline"
                            >
                              Disconnect File
                            </button>
                          </div>
                        ) : (
                          <div className="flex flex-col items-center gap-1.5">
                            <FileDown className="h-8 w-8 text-indigo-400" />
                            <span className="text-xs font-bold text-slate-700">Drag & drop your GSC search performance export file here</span>
                            <p className="text-[10px] text-slate-400">or click to browse from local computer. Supports .csv and .json sheets</p>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                )}
              </div>

              {/* Data Range, Target Location & Submit Action */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 border-t border-slate-100 pt-6">
                <div className="space-y-1.5">
                  <label htmlFor="location" className="text-xs font-bold text-slate-700 block">
                    Target Location / Region
                  </label>
                  <div className="relative">
                    <MapPin className="absolute left-3.5 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
                    <select
                      id="location"
                      value={location}
                      onChange={(e) => setLocation(e.target.value)}
                      className="w-full bg-slate-50 border border-slate-200 rounded-xl pl-10 pr-4 py-2.5 text-sm focus:bg-white focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 outline-none transition cursor-pointer"
                    >
                      <option value="United States">United States (US)</option>
                      <option value="United Kingdom">United Kingdom (UK)</option>
                      <option value="Canada">Canada (CA)</option>
                      <option value="Australia">Australia (AU)</option>
                      <option value="Germany">Germany (DE)</option>
                      <option value="France">France (FR)</option>
                      <option value="India">India (IN)</option>
                      <option value="Japan">Japan (JP)</option>
                    </select>
                  </div>
                </div>

                <div className="space-y-1.5">
                  <label htmlFor="duration" className="text-xs font-bold text-slate-700 block">
                    Historical Timeline Range
                  </label>
                  <div className="relative">
                    <Calendar className="absolute left-3.5 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
                    <select
                      id="duration"
                      value={duration}
                      onChange={(e) => setDuration(e.target.value)}
                      className="w-full bg-slate-50 border border-slate-200 rounded-xl pl-10 pr-4 py-2.5 text-sm focus:bg-white focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 outline-none transition cursor-pointer"
                    >
                      <option value="Last 7 Days">Last 7 Days</option>
                      <option value="Last 30 Days">Last 30 Days</option>
                      <option value="Last 90 Days">Last 90 Days</option>
                      <option value="Last 12 Months">Last 12 Months</option>
                    </select>
                  </div>
                </div>

                <div className="flex items-end">
                  <button
                    type="submit"
                    disabled={isAnalyzing}
                    className="w-full py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded-xl shadow-lg shadow-indigo-500/10 flex items-center justify-center gap-2 transition cursor-pointer disabled:bg-slate-300 disabled:cursor-not-allowed text-xs"
                  >
                    {isAnalyzing ? (
                      <>
                        <RefreshCw className="h-4 w-4 animate-spin" />
                        <span>Generating Snapshots...</span>
                      </>
                    ) : (
                      <>
                        <Zap className="h-4 w-4 text-amber-300 fill-amber-300" />
                        <span>Compile Report Snapshots</span>
                      </>
                    )}
                  </button>
                </div>
              </div>
            </form>
          </div>
        </main>
      ) : (
        // DASHBOARD INTERFACE
        <div className="flex-1 flex flex-col md:flex-row">
          {/* NAVIGATION SIDEBAR */}
          <aside className="w-full md:w-64 bg-white border-r border-slate-200 shrink-0 py-6 px-4 flex flex-col gap-1.5">
            <div className="px-3 mb-4">
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block">Intelligence Core</span>
            </div>

            <button
              onClick={() => setActiveTab('overview')}
              className={`flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-semibold transition text-left cursor-pointer ${
                activeTab === 'overview' ? 'bg-indigo-50 text-indigo-700' : 'text-slate-600 hover:bg-slate-50'
              }`}
            >
              <Activity className="h-4.5 w-4.5" />
              <span>Executive Overview</span>
            </button>

            <button
              onClick={() => setActiveTab('keywords')}
              className={`flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-semibold transition text-left cursor-pointer ${
                activeTab === 'keywords' ? 'bg-indigo-50 text-indigo-700' : 'text-slate-600 hover:bg-slate-50'
              }`}
            >
              <Search className="h-4.5 w-4.5" />
              <span>Keyword Dashboard</span>
            </button>

            <button
              onClick={() => setActiveTab('clusters')}
              className={`flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-semibold transition text-left cursor-pointer ${
                activeTab === 'clusters' ? 'bg-indigo-50 text-indigo-700' : 'text-slate-600 hover:bg-slate-50'
              }`}
            >
              <Layers className="h-4.5 w-4.5" />
              <span>Topic Clusters Map</span>
            </button>

            <button
              onClick={() => setActiveTab('gaps')}
              className={`flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-semibold transition text-left cursor-pointer ${
                activeTab === 'gaps' ? 'bg-indigo-50 text-indigo-700' : 'text-slate-600 hover:bg-slate-50'
              }`}
            >
              <Database className="h-4.5 w-4.5" />
              <span>Gap Analysis</span>
            </button>

            <div className="px-3 my-4">
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block">Workflows</span>
            </div>

            <button
              onClick={() => setActiveTab('studio')}
              className={`flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-semibold transition text-left cursor-pointer ${
                activeTab === 'studio' ? 'bg-indigo-50 text-indigo-700' : 'text-slate-600 hover:bg-slate-50'
              }`}
            >
              <Sparkles className="h-4.5 w-4.5 text-indigo-600" />
              <span>AI Content Studio</span>
            </button>

            <button
              onClick={() => setActiveTab('reports')}
              className={`flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-semibold transition text-left cursor-pointer ${
                activeTab === 'reports' ? 'bg-indigo-50 text-indigo-700' : 'text-slate-600 hover:bg-slate-50'
              }`}
            >
              <FileText className="h-4.5 w-4.5" />
              <span>Reports</span>
            </button>

            <button
              onClick={() => setActiveTab('alerts')}
              className={`flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-semibold transition text-left cursor-pointer ${
                activeTab === 'alerts' ? 'bg-indigo-50 text-indigo-700' : 'text-slate-600 hover:bg-slate-50'
              }`}
            >
              <AlertCircle className="h-4.5 w-4.5" />
              <span className="flex items-center justify-between w-full">
                <span>Alerts & Monitor</span>
                <span className="bg-rose-100 text-rose-700 text-[10px] px-1.5 py-0.5 rounded-full font-bold">4</span>
              </span>
            </button>

            <div className="mt-auto pt-6 border-t border-slate-100 text-center">
              <span className="text-[10px] text-slate-400 font-semibold block">Data provided via DataForSEO</span>
              <span className="text-[10px] text-slate-400 font-semibold block mt-0.5">And Server-Side Gemini 3.5</span>
            </div>
          </aside>

          {/* MAIN PAGE CONTAINER */}
          <main className="flex-1 bg-slate-50 p-6 md:p-8 overflow-y-auto max-w-7xl mx-auto w-full">
            
            {/* 1. EXECUTIVE OVERVIEW TAB */}
            {activeTab === 'overview' && (
              <div className="space-y-6">
                <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-200 pb-5">
                  <div>
                    <h2 className="text-2xl font-extrabold text-slate-900 tracking-tight">Executive Intelligence Dashboard</h2>
                    <p className="text-sm text-slate-500 mt-1">
                      High-level organic search performance and authority comparison for entered domains
                    </p>
                  </div>
                  <button
                    onClick={() => handleExportReport('MD')}
                    className="px-4 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-xs font-bold flex items-center gap-2 transition cursor-pointer self-start md:self-auto"
                  >
                    <Download className="h-4 w-4" />
                    <span>Download MD Report</span>
                  </button>
                </div>

                {/* Scorecards */}
                <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
                  <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm">
                    <span className="text-xs font-bold text-slate-400 uppercase tracking-wider block">Content Health Score</span>
                    <div className="flex items-baseline gap-2 mt-2">
                      <span className="text-3xl font-black text-slate-800">{result.overview.contentHealthScore}%</span>
                      <span className="text-xs font-bold text-emerald-600 flex items-center gap-0.5">
                        <TrendingUp className="h-3 w-3" /> +2.1%
                      </span>
                    </div>
                    <div className="w-full bg-slate-100 h-1.5 rounded-full mt-3 overflow-hidden">
                      <div className="bg-emerald-500 h-full rounded-full" style={{ width: `${result.overview.contentHealthScore}%` }}></div>
                    </div>
                  </div>

                  <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm">
                    <span className="text-xs font-bold text-slate-400 uppercase tracking-wider block">Total Keywords</span>
                    <div className="flex items-baseline gap-2 mt-2">
                      <span className="text-3xl font-black text-indigo-700">{result.overview.totalKeywordsSelf.toLocaleString()}</span>
                      <span className="text-xs font-bold text-emerald-600">Active</span>
                    </div>
                    <div className="w-full bg-slate-100 h-1.5 rounded-full mt-3 overflow-hidden">
                      <div className="bg-indigo-600 h-full rounded-full" style={{ width: '100%' }}></div>
                    </div>
                  </div>

                  <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm">
                    <span className="text-xs font-bold text-slate-400 uppercase tracking-wider block">Content Gap Score</span>
                    <div className="flex items-baseline gap-2 mt-2">
                      <span className="text-3xl font-black text-rose-600">{result.overview.contentGapScore}%</span>
                      <span className="text-xs font-bold text-rose-500">High Gaps</span>
                    </div>
                    <div className="w-full bg-slate-100 h-1.5 rounded-full mt-3 overflow-hidden">
                      <div className="bg-rose-500 h-full rounded-full" style={{ width: `${result.overview.contentGapScore}%` }}></div>
                    </div>
                  </div>

                  <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm">
                    <span className="text-xs font-bold text-slate-400 uppercase tracking-wider block">Overall SEO Score</span>
                    <div className="flex items-baseline gap-2 mt-2">
                      <span className="text-3xl font-black text-slate-800">{result.overview.seoScore}/100</span>
                      <span className="text-xs font-bold text-emerald-600">Stable</span>
                    </div>
                    <div className="w-full bg-slate-100 h-1.5 rounded-full mt-3 overflow-hidden">
                      <div className="bg-indigo-500 h-full rounded-full" style={{ width: `${result.overview.seoScore}%` }}></div>
                    </div>
                  </div>
                </div>

                {/* Traffic vs Competitor Chart */}
                <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                  <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm lg:col-span-2 space-y-4">
                    <div className="flex justify-between items-center">
                      <h3 className="text-lg font-bold text-slate-900">Organic Traffic Share</h3>
                      <span className="text-xs font-semibold text-slate-400">Estimated monthly visits</span>
                    </div>

                    <div className="space-y-4 pt-4">
                      {/* Self */}
                      <div>
                        <div className="flex justify-between text-xs font-bold mb-1.5">
                          <span className="text-indigo-600">Self Website ({result.selfUrl.replace('https://', '')})</span>
                          <span>{result.overview.organicTrafficSelf.toLocaleString()} visits</span>
                        </div>
                        <div className="w-full bg-slate-100 h-3.5 rounded-full overflow-hidden flex">
                          <div className="bg-indigo-600 h-full" style={{ width: `${(result.overview.organicTrafficSelf / (result.overview.organicTrafficSelf + result.overview.organicTrafficCompA + result.overview.organicTrafficCompB)) * 100}%` }}></div>
                        </div>
                      </div>

                      {/* Competitor A */}
                      <div>
                        <div className="flex justify-between text-xs font-bold mb-1.5">
                          <span className="text-slate-600">Competitor A ({result.competitorA.replace('https://', '')})</span>
                          <span>{result.overview.organicTrafficCompA.toLocaleString()} visits</span>
                        </div>
                        <div className="w-full bg-slate-100 h-3.5 rounded-full overflow-hidden flex">
                          <div className="bg-slate-400 h-full" style={{ width: `${(result.overview.organicTrafficCompA / (result.overview.organicTrafficSelf + result.overview.organicTrafficCompA + result.overview.organicTrafficCompB)) * 100}%` }}></div>
                        </div>
                      </div>

                      {/* Competitor B */}
                      <div>
                        <div className="flex justify-between text-xs font-bold mb-1.5">
                          <span className="text-slate-600">Competitor B ({result.competitorB.replace('https://', '')})</span>
                          <span>{result.overview.organicTrafficCompB.toLocaleString()} visits</span>
                        </div>
                        <div className="w-full bg-slate-100 h-3.5 rounded-full overflow-hidden flex">
                          <div className="bg-slate-300 h-full" style={{ width: `${(result.overview.organicTrafficCompB / (result.overview.organicTrafficSelf + result.overview.organicTrafficCompA + result.overview.organicTrafficCompB)) * 100}%` }}></div>
                        </div>
                      </div>
                    </div>

                    <div className="bg-indigo-50 p-4 rounded-2xl flex items-start gap-3 mt-4">
                      <Zap className="h-5 w-5 text-indigo-600 shrink-0 mt-0.5" />
                      <div>
                        <h4 className="text-xs font-bold text-indigo-900">AI Core Strategic Takeaway</h4>
                        <p className="text-xs text-indigo-700 mt-1 leading-relaxed">
                          Your competitors pull over 70% of industry-focused informational intent keywords. Creating content clusters around <strong>"{result.clusters[0]?.name || 'new topics'}"</strong> can secure up to +{result.recommendations[0]?.estimatedTraffic || '3,000'} monthly visits immediately.
                        </p>
                      </div>
                    </div>
                  </div>

                  {/* Right Column Priority Action list */}
                  <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm flex flex-col justify-between">
                    <div>
                      <h3 className="text-lg font-bold text-slate-900">Priority Recommendations</h3>
                      <p className="text-xs text-slate-400 font-medium mt-1">Highest impact tasks to build first</p>
                      
                      <div className="space-y-3.5 mt-5">
                        {result.recommendations.slice(0, 3).map((rec, idx) => (
                          <div key={idx} className="p-3 border border-slate-100 hover:border-slate-200 rounded-xl flex items-start gap-2.5 transition">
                            <div className="bg-indigo-50 text-indigo-700 p-1.5 rounded-lg text-xs font-extrabold shrink-0">
                              #{idx + 1}
                            </div>
                            <div className="flex-1 min-w-0">
                              <h4 className="text-xs font-bold text-slate-800 truncate">{rec.title}</h4>
                              <p className="text-[10px] text-slate-400 truncate mt-0.5">{rec.reason}</p>
                              <div className="flex items-center gap-2 mt-2">
                                <span className={`text-[9px] font-bold px-1.5 py-0.5 rounded-full ${rec.priority === 'high' ? 'bg-red-50 text-red-600' : 'bg-slate-100 text-slate-600'}`}>
                                  {rec.priority.toUpperCase()}
                                </span>
                                <span className="text-[9px] font-bold text-slate-500">
                                  Gain: +{rec.estimatedTraffic}/mo
                                </span>
                              </div>
                            </div>
                            <button
                              onClick={() => handleQuickWrite(rec.title)}
                              className="p-1.5 text-indigo-600 hover:bg-indigo-50 rounded-lg shrink-0 cursor-pointer"
                              title="Write Content"
                            >
                              <Edit className="h-4 w-4" />
                            </button>
                          </div>
                        ))}
                      </div>
                    </div>

                    <button
                      onClick={() => setActiveTab('recommendations')}
                      className="w-full mt-6 py-2.5 bg-slate-100 hover:bg-slate-200/80 text-slate-800 font-bold text-xs rounded-xl flex items-center justify-center gap-1 transition cursor-pointer"
                    >
                      <span>View All Recommendations</span>
                      <ArrowRight className="h-3 w-3" />
                    </button>
                  </div>
                </div>

                {/* Sub dashboards links */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  {/* Keywords summary */}
                  <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm space-y-3">
                    <div className="flex items-center gap-2 text-indigo-600">
                      <Search className="h-5 w-5" />
                      <h4 className="font-bold text-sm text-slate-900">Keywords Gap Status</h4>
                    </div>
                    <p className="text-xs text-slate-500 leading-relaxed">
                      You rank for <strong>{result.overview.rankingKeywordsSelf}</strong> keywords, while competitors capture over <strong>{result.overview.rankingKeywordsCompA}</strong>.
                    </p>
                    <button onClick={() => setActiveTab('keywords')} className="text-xs font-bold text-indigo-600 hover:underline flex items-center gap-1 mt-2">
                      <span>Explore keyword directory</span>
                      <ChevronRight className="h-3.5 w-3.5" />
                    </button>
                  </div>

                  {/* Clusters summary */}
                  <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm space-y-3">
                    <div className="flex items-center gap-2 text-emerald-600">
                      <Layers className="h-5 w-5" />
                      <h4 className="font-bold text-sm text-slate-900">Topic Cluster Authority</h4>
                    </div>
                    <p className="text-xs text-slate-500 leading-relaxed">
                      We discovered <strong>{result.clusters.length} distinct clusters</strong> with critical gaps. Competitors have authoritative coverage in billing & integration guides.
                    </p>
                    <button onClick={() => setActiveTab('clusters')} className="text-xs font-bold text-emerald-600 hover:underline flex items-center gap-1 mt-2">
                      <span>View cluster connection map</span>
                      <ChevronRight className="h-3.5 w-3.5" />
                    </button>
                  </div>

                  {/* Recommendations summary */}
                  <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm space-y-3">
                    <div className="flex items-center gap-2 text-amber-600">
                      <Award className="h-5 w-5" />
                      <h4 className="font-bold text-sm text-slate-900">SEO Priorities Roadmap</h4>
                    </div>
                    <p className="text-xs text-slate-500 leading-relaxed">
                      You have <strong>{result.recommendations.length} recommendations</strong> with high impact. Focus on unbuilt content guides first to secure traffic.
                    </p>
                    <button onClick={() => setActiveTab('recommendations')} className="text-xs font-bold text-amber-600 hover:underline flex items-center gap-1 mt-2">
                      <span>View actionable task roadmap</span>
                      <ChevronRight className="h-3.5 w-3.5" />
                    </button>
                  </div>
                </div>
              </div>
            )}

            {/* 2. KEYWORD DASHBOARD TAB */}
            {activeTab === 'keywords' && (
              <div className="space-y-6">
                <div>
                  <h2 className="text-2xl font-extrabold text-slate-900 tracking-tight">Keyword Opportunity Matrix</h2>
                  <p className="text-sm text-slate-500 mt-1">Analyze organic rankings and search volume compared side-by-side</p>
                </div>

                {/* Filters Row */}
                <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm space-y-4">
                  <div className="flex flex-col md:flex-row gap-4">
                    {/* Search bar */}
                    <div className="relative flex-1">
                      <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
                      <input
                        type="text"
                        placeholder="Search keywords or cluster categories..."
                        value={kwSearch}
                        onChange={(e) => setKwSearch(e.target.value)}
                        className="w-full bg-slate-50 border border-slate-200 rounded-xl pl-9 pr-4 py-2 text-sm outline-none focus:bg-white focus:ring-2 focus:ring-indigo-500/20"
                      />
                    </div>

                    {/* Intent Filter */}
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-bold text-slate-400 uppercase">Intent</span>
                      <select
                        value={kwIntentFilter}
                        onChange={(e) => setKwIntentFilter(e.target.value)}
                        className="bg-slate-50 border border-slate-200 rounded-xl px-3 py-1.5 text-xs font-bold text-slate-700 outline-none"
                      >
                        <option value="all">All Intents</option>
                        <option value="Informational">Informational</option>
                        <option value="Transactional">Transactional</option>
                        <option value="Commercial">Commercial</option>
                        <option value="Navigational">Navigational</option>
                      </select>
                    </div>

                    {/* Difficulty Filter */}
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-bold text-slate-400 uppercase">Difficulty</span>
                      <select
                        value={kwDifficultyFilter}
                        onChange={(e) => setKwDifficultyFilter(e.target.value)}
                        className="bg-slate-50 border border-slate-200 rounded-xl px-3 py-1.5 text-xs font-bold text-slate-700 outline-none"
                      >
                        <option value="all">All Difficulties</option>
                        <option value="easy">Easy (&lt; 40%)</option>
                        <option value="medium">Medium (40% - 65%)</option>
                        <option value="hard">Hard (&gt; 65%)</option>
                      </select>
                    </div>

                    {/* Position Gap Filter */}
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-bold text-slate-400 uppercase">Position Status</span>
                      <select
                        value={kwPositionFilter}
                        onChange={(e) => setKwPositionFilter(e.target.value)}
                        className="bg-slate-50 border border-slate-200 rounded-xl px-3 py-1.5 text-xs font-bold text-slate-700 outline-none"
                      >
                        <option value="all">All Keywords</option>
                        <option value="not-ranking">Not Ranking (Opportunity)</option>
                        <option value="page-1">Ranking Page 1 (Top 10)</option>
                        <option value="ranking-behind">Behind Competitor Rankings</option>
                      </select>
                    </div>
                  </div>
                </div>

                {/* Keywords Table */}
                <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
                  <div className="overflow-x-auto">
                    <table className="w-full text-left border-collapse">
                      <thead>
                        <tr className="bg-slate-50 border-b border-slate-200 text-slate-400 text-[10px] uppercase font-bold tracking-wider">
                          <th className="py-4 px-6">Keyword Target</th>
                          <th className="py-4 px-4">Cluster Category</th>
                          <th className="py-4 px-4">Search Volume</th>
                          <th className="py-4 px-4">KD %</th>
                          <th className="py-4 px-4 text-center">Self Rank</th>
                          <th className="py-4 px-4 text-center">Comp A Rank</th>
                          <th className="py-4 px-4 text-center">Comp B Rank</th>
                          <th className="py-4 px-4">Search Intent</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100 text-xs">
                        {filteredKeywords.length > 0 ? (
                          filteredKeywords.map((k) => (
                            <tr key={k.id} className="hover:bg-slate-50/50 transition">
                              <td className="py-4 px-6">
                                <span className="font-bold text-slate-900 block">{k.keyword}</span>
                                {k.branded && (
                                  <span className="bg-indigo-50 text-indigo-600 text-[9px] font-bold px-1.5 py-0.5 rounded-full mt-1 inline-block">Branded</span>
                                )}
                              </td>
                              <td className="py-4 px-4">
                                <span className="bg-slate-100 text-slate-600 px-2 py-1 rounded-lg font-bold">{k.cluster}</span>
                              </td>
                              <td className="py-4 px-4 font-bold text-slate-700">
                                {k.volume.toLocaleString()}
                              </td>
                              <td className="py-4 px-4">
                                <div className="flex items-center gap-2">
                                  <span className="font-bold text-slate-700">{k.difficulty}%</span>
                                  <div className="w-12 bg-slate-100 h-1.5 rounded-full overflow-hidden">
                                    <div 
                                      className={`h-full rounded-full ${k.difficulty > 65 ? 'bg-red-500' : k.difficulty >= 40 ? 'bg-amber-400' : 'bg-emerald-500'}`}
                                      style={{ width: `${k.difficulty}%` }}
                                    ></div>
                                  </div>
                                </div>
                              </td>
                              <td className="py-4 px-4 text-center font-bold">
                                {k.positionSelf > 0 ? (
                                  <span className={`px-2 py-1 rounded-full ${k.positionSelf <= 3 ? 'bg-emerald-50 text-emerald-700' : 'bg-slate-100 text-slate-700'}`}>
                                    #{k.positionSelf}
                                  </span>
                                ) : (
                                  <span className="text-slate-400">—</span>
                                )}
                              </td>
                              <td className="py-4 px-4 text-center font-semibold text-slate-600">
                                {k.positionCompA > 0 ? `#${k.positionCompA}` : '—'}
                              </td>
                              <td className="py-4 px-4 text-center font-semibold text-slate-600">
                                {k.positionCompB > 0 ? `#${k.positionCompB}` : '—'}
                              </td>
                              <td className="py-4 px-4">
                                <span className={`px-2 py-1 rounded-md text-[10px] font-bold ${
                                  k.intent === 'Informational' ? 'bg-blue-50 text-blue-700' :
                                  k.intent === 'Transactional' ? 'bg-emerald-50 text-emerald-700' :
                                  k.intent === 'Commercial' ? 'bg-purple-50 text-purple-700' :
                                  'bg-slate-100 text-slate-600'
                                }`}>
                                  {k.intent}
                                </span>
                              </td>
                            </tr>
                          ))
                        ) : (
                          <tr>
                            <td colSpan={8} className="py-12 text-center text-slate-400 font-semibold">
                              No keywords matched your filters. Adjust filters to search.
                            </td>
                          </tr>
                        )}
                      </tbody>
                    </table>
                  </div>
                </div>

                {/* Simulated alert info box */}
                <div className="bg-amber-50 border border-amber-200 p-4 rounded-2xl flex gap-3">
                  <AlertCircle className="h-5 w-5 text-amber-500 shrink-0 mt-0.5" />
                  <div className="text-xs text-amber-800 leading-relaxed">
                    <span className="font-bold block mb-1">High Intent Search Gap Identified:</span>
                    We discovered that Competitor A holds position #1 or #2 for all transactional variations in the <strong>"{result.clusters[0]?.name}"</strong> node. This accounts for an estimated monthly gap of <strong>8,300 monthly organic pageviews</strong>.
                  </div>
                </div>
              </div>
            )}

            {/* 3. TOPIC CLUSTER DASHBOARD TAB */}
            {activeTab === 'clusters' && (
              <div className="space-y-6">
                <div>
                  <h2 className="text-2xl font-extrabold text-slate-900 tracking-tight">Thematic Content Graph</h2>
                  <p className="text-sm text-slate-500 mt-1">Visually examine semantic clusters and identify immediate content build opportunities</p>
                </div>

                {/* Dual Column Layout: Left visual tree, Right Selected Cluster details */}
                <div className="grid grid-cols-1 lg:grid-cols-5 gap-6">
                  
                  {/* Visual Node Cluster Column */}
                  <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm lg:col-span-3 space-y-4">
                    <h3 className="text-sm font-bold text-slate-400 uppercase tracking-wider">Semantic Architecture Model</h3>
                    
                    {/* Visual Tree Diagram */}
                    <div className="border border-slate-100 rounded-2xl p-6 bg-slate-50/50 flex flex-col items-center justify-center relative min-h-[400px]">
                      
                      {/* Central Core Node */}
                      <div className="bg-indigo-600 text-white px-5 py-3 rounded-2xl shadow-lg z-10 text-center relative border-2 border-indigo-400">
                        <Database className="h-5 w-5 mx-auto mb-1" />
                        <span className="text-xs font-black tracking-tight uppercase">Topic Authority Root</span>
                        <span className="text-[10px] text-indigo-200 block truncate mt-0.5">{result.selfUrl.replace('https://', '')}</span>
                      </div>

                      {/* Connection pathways to sub nodes */}
                      <div className="w-full max-w-4xl grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4 mt-16 relative">
                        {result.clusters.map((c, index) => {
                          const isSelected = selectedClusterId === c.id;
                          return (
                            <button
                              key={c.id}
                              onClick={() => setSelectedClusterId(c.id)}
                              className={`p-4 rounded-2xl border text-left flex flex-col justify-between transition relative z-10 cursor-pointer ${
                                isSelected 
                                  ? 'bg-white border-indigo-600 ring-4 ring-indigo-50 shadow-md' 
                                  : 'bg-white border-slate-200 hover:border-slate-300'
                              }`}
                            >
                              {/* Connector line overlay simulating connection diagram */}
                              <div className="absolute -top-12 left-1/2 -translate-x-1/2 w-0.5 h-12 bg-slate-200 -z-10"></div>
                              
                              <div>
                                <span className={`text-[9px] font-bold px-1.5 py-0.5 rounded-full ${
                                  c.status === 'covered' ? 'bg-emerald-50 text-emerald-700' :
                                  c.status === 'partial' ? 'bg-amber-50 text-amber-700' :
                                  'bg-rose-50 text-rose-700'
                                }`}>
                                  {c.status.toUpperCase()}
                                </span>
                                <h4 className="text-sm font-extrabold text-slate-800 mt-2">{c.name}</h4>
                                <span className="text-[10px] text-slate-400 block mt-1">{c.keywordsCount} search phrases</span>
                              </div>

                              <div className="border-t border-slate-100 pt-3 mt-4 flex items-center justify-between">
                                <span className="text-[10px] text-slate-400">Opportunity</span>
                                <span className="text-xs font-black text-slate-800">{c.opportunityScore}%</span>
                              </div>
                            </button>
                          );
                        })}
                      </div>

                    </div>

                    <p className="text-center text-xs text-slate-400 font-medium">
                      Select any cluster node above to examine associated keywords, citation checkpoints, and unbuilt pages.
                    </p>
                  </div>

                  {/* Right Detail Panel Column */}
                  <div className="lg:col-span-2 space-y-6">
                    {selectedCluster ? (
                      <div className="bg-white rounded-3xl border border-slate-200 shadow-sm p-6 space-y-5">
                        <div className="flex justify-between items-start border-b border-slate-100 pb-4">
                          <div>
                            <span className="text-[10px] font-extrabold text-indigo-600 tracking-wider block uppercase">Selected Cluster Detail</span>
                            <h3 className="text-xl font-extrabold text-slate-900 mt-1">{selectedCluster.name}</h3>
                          </div>
                          <div className="text-right">
                            <span className="text-[10px] font-bold text-slate-400 block">Opportunity</span>
                            <span className="text-lg font-black text-rose-600">{selectedCluster.opportunityScore}%</span>
                          </div>
                        </div>

                        <p className="text-xs text-slate-500 leading-relaxed">
                          {selectedCluster.description}
                        </p>

                        {/* Associated Keywords */}
                        <div className="space-y-2">
                          <span className="text-xs font-bold text-slate-400 uppercase tracking-wider block">Target Keywords In Cluster</span>
                          <div className="flex flex-wrap gap-2">
                            {selectedCluster.keywords.map((kw, i) => (
                              <span key={i} className="bg-slate-50 border border-slate-200 text-slate-600 px-2.5 py-1 rounded-xl text-xs font-semibold">
                                {kw}
                              </span>
                            ))}
                          </div>
                        </div>

                        {/* Covered Articles */}
                        <div className="space-y-2.5 border-t border-slate-100 pt-4">
                          <span className="text-xs font-bold text-slate-400 uppercase tracking-wider block">Existing Self Content ({selectedCluster.articles.length})</span>
                          {selectedCluster.articles.length > 0 ? (
                            <ul className="space-y-3">
                              {selectedCluster.articles.map((art, idx) => {
                                const slug = art.toLowerCase().replace(/[^a-z0-9 ]/g, '').replace(/\s+/g, '-');
                                const fullUrl = `${result.selfUrl.replace(/\/$/, '')}/${slug}`;
                                return (
                                  <li key={idx} className="text-xs flex flex-col gap-1 bg-slate-50 border border-slate-150 p-2.5 rounded-xl">
                                    <div className="flex items-center gap-2">
                                      <CheckCircle2 className="h-4 w-4 text-emerald-500 shrink-0" />
                                      <span className="font-extrabold text-slate-800">{art}</span>
                                    </div>
                                    <a 
                                      href={fullUrl} 
                                      target="_blank" 
                                      rel="noopener noreferrer" 
                                      className="text-[10px] text-indigo-600 hover:underline hover:text-indigo-500 font-semibold block truncate pl-6"
                                    >
                                      {fullUrl}
                                    </a>
                                  </li>
                                );
                              })}
                            </ul>
                          ) : (
                            <span className="text-xs text-slate-400 italic block">No indexable pages detected in this cluster. Complete gap detected.</span>
                          )}
                        </div>

                        {/* Missing Content opportunities */}
                        <div className="space-y-2 border-t border-slate-100 pt-4">
                          <span className="text-xs font-bold text-rose-500 uppercase tracking-wider block">Competitor-Only Pages (Your Gaps)</span>
                          {selectedCluster.missingContent.length > 0 ? (
                            <div className="space-y-2">
                              {selectedCluster.missingContent.map((item, idx) => (
                                <div key={idx} className="p-3 bg-rose-50/50 border border-rose-100 rounded-xl flex items-center justify-between gap-2">
                                  <span className="text-xs font-bold text-slate-800 truncate">{item}</span>
                                  <button
                                    onClick={() => handleQuickWrite(item, selectedCluster.keywords)}
                                    className="px-2 py-1 bg-white hover:bg-rose-100 text-rose-700 font-bold text-[10px] rounded-lg border border-rose-200 transition shrink-0 cursor-pointer"
                                  >
                                    Create Article
                                  </button>
                                </div>
                              ))}
                            </div>
                          ) : (
                            <span className="text-xs text-slate-400 italic block">None! This cluster is beautifully guarded.</span>
                          )}
                        </div>

                      </div>
                    ) : (
                      <div className="bg-white rounded-3xl border border-slate-200 shadow-sm p-6 text-center text-slate-400 font-semibold py-12">
                        Select a cluster on the left to review gaps.
                      </div>
                    )}
                  </div>

                </div>
              </div>
            )}

            {/* 4. COMPETITORS METRICS TAB */}
            {activeTab === 'competitors' && (
              <div className="space-y-6">
                <div>
                  <h2 className="text-2xl font-extrabold text-slate-900 tracking-tight">Competitor Intelligence Matrix</h2>
                  <p className="text-sm text-slate-500 mt-1">Deep analysis of performance indicators against domains A and B</p>
                </div>

                {/* Grid comparing the three websites */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  
                  {/* Self Side */}
                  <div className="bg-white rounded-3xl border-2 border-indigo-600 shadow-sm overflow-hidden flex flex-col justify-between">
                    <div className="bg-indigo-600 text-white p-5 text-center relative">
                      <span className="text-[10px] font-black uppercase tracking-widest text-indigo-200">Main Focus</span>
                      <h3 className="text-lg font-extrabold truncate mt-1">{result.selfUrl.replace('https://', '')}</h3>
                      <span className="absolute top-2 right-2 bg-white text-indigo-700 text-[9px] font-black px-1.5 py-0.5 rounded-full">SELF</span>
                    </div>
                    
                    <div className="p-6 space-y-4 flex-1">
                      <div className="grid grid-cols-2 gap-4 border-b border-slate-100 pb-4">
                        <div>
                          <span className="text-[10px] text-slate-400 block font-bold uppercase">DA Score</span>
                          <span className="text-xl font-black text-slate-800">54</span>
                        </div>
                        <div>
                          <span className="text-[10px] text-slate-400 block font-bold uppercase">Organic Traffic</span>
                          <span className="text-xl font-black text-slate-800">{result.overview.organicTrafficSelf.toLocaleString()}</span>
                        </div>
                      </div>

                      <div className="space-y-3">
                        <div className="flex justify-between text-xs">
                          <span className="text-slate-500">Ranking Keywords:</span>
                          <span className="font-bold text-slate-800">{result.overview.rankingKeywordsSelf}</span>
                        </div>
                        <div className="flex justify-between text-xs">
                          <span className="text-slate-500">Avg. Position:</span>
                          <span className="font-bold text-slate-800">32.4</span>
                        </div>
                        <div className="flex justify-between text-xs">
                          <span className="text-slate-500">Thematic Articles:</span>
                          <span className="font-bold text-slate-800">22</span>
                        </div>
                        <div className="flex justify-between text-xs">
                          <span className="text-slate-500">Keyword Growth:</span>
                          <span className="font-bold text-emerald-600">+4.2%</span>
                        </div>
                      </div>

                    </div>
                  </div>

                  {/* Competitor A Side */}
                  <div className="bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden flex flex-col justify-between">
                    <div className="bg-slate-900 text-white p-5 text-center">
                      <span className="text-[10px] font-bold uppercase tracking-widest text-slate-400">Competitor A</span>
                      <h3 className="text-lg font-extrabold truncate mt-1">{result.competitorA.replace('https://', '')}</h3>
                    </div>
                    
                    <div className="p-6 space-y-4 flex-1">
                      <div className="grid grid-cols-2 gap-4 border-b border-slate-100 pb-4">
                        <div>
                          <span className="text-[10px] text-slate-400 block font-bold uppercase">DA Score</span>
                          <span className="text-xl font-black text-slate-800">{result.compAMetrics.domainAuthority}</span>
                        </div>
                        <div>
                          <span className="text-[10px] text-slate-400 block font-bold uppercase">Organic Traffic</span>
                          <span className="text-xl font-black text-slate-800">{result.compAMetrics.traffic.toLocaleString()}</span>
                        </div>
                      </div>

                      <div className="space-y-3">
                        <div className="flex justify-between text-xs">
                          <span className="text-slate-500">Ranking Keywords:</span>
                          <span className="font-bold text-slate-800">{result.compAMetrics.rankingKeywords}</span>
                        </div>
                        <div className="flex justify-between text-xs">
                          <span className="text-slate-500">Avg. Position:</span>
                          <span className="font-bold text-slate-800">{result.compAMetrics.avgPosition}</span>
                        </div>
                        <div className="flex justify-between text-xs">
                          <span className="text-slate-500">Thematic Articles:</span>
                          <span className="font-bold text-slate-800">{result.compAMetrics.contentCount}</span>
                        </div>
                        <div className="flex justify-between text-xs">
                          <span className="text-slate-500">Keyword Growth:</span>
                          <span className="font-bold text-emerald-600">+{result.compAMetrics.keywordGrowth}%</span>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Competitor B Side */}
                  <div className="bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden flex flex-col justify-between">
                    <div className="bg-slate-800 text-white p-5 text-center">
                      <span className="text-[10px] font-bold uppercase tracking-widest text-slate-400">Competitor B</span>
                      <h3 className="text-lg font-extrabold truncate mt-1">{result.competitorB.replace('https://', '')}</h3>
                    </div>
                    
                    <div className="p-6 space-y-4 flex-1">
                      <div className="grid grid-cols-2 gap-4 border-b border-slate-100 pb-4">
                        <div>
                          <span className="text-[10px] text-slate-400 block font-bold uppercase">DA Score</span>
                          <span className="text-xl font-black text-slate-800">{result.compBMetrics.domainAuthority}</span>
                        </div>
                        <div>
                          <span className="text-[10px] text-slate-400 block font-bold uppercase">Organic Traffic</span>
                          <span className="text-xl font-black text-slate-800">{result.compBMetrics.traffic.toLocaleString()}</span>
                        </div>
                      </div>

                      <div className="space-y-3">
                        <div className="flex justify-between text-xs">
                          <span className="text-slate-500">Ranking Keywords:</span>
                          <span className="font-bold text-slate-800">{result.compBMetrics.rankingKeywords}</span>
                        </div>
                        <div className="flex justify-between text-xs">
                          <span className="text-slate-500">Avg. Position:</span>
                          <span className="font-bold text-slate-800">{result.compBMetrics.avgPosition}</span>
                        </div>
                        <div className="flex justify-between text-xs">
                          <span className="text-slate-500">Thematic Articles:</span>
                          <span className="font-bold text-slate-800">{result.compBMetrics.contentCount}</span>
                        </div>
                        <div className="flex justify-between text-xs">
                          <span className="text-slate-500">Keyword Growth:</span>
                          <span className="font-bold text-emerald-600">+{result.compBMetrics.keywordGrowth}%</span>
                        </div>
                      </div>
                    </div>
                  </div>

                </div>

                {/* Top pages comparing side by side */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {/* Comp A Top pages */}
                  <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm space-y-4">
                    <h3 className="text-sm font-bold text-slate-400 uppercase tracking-wider">Top Performing Landing Pages (Comp A)</h3>
                    <div className="space-y-3">
                      {result.compAMetrics.topPages.map((page, idx) => (
                        <div key={idx} className="p-3 bg-slate-50 border border-slate-100 rounded-xl flex items-center justify-between gap-4">
                          <div className="min-w-0">
                            <span className="text-xs font-bold text-slate-800 truncate block">{page.url}</span>
                            <span className="text-[10px] text-slate-400 block mt-0.5">{page.keywordsCount} ranking terms</span>
                          </div>
                          <div className="text-right shrink-0">
                            <span className="text-xs font-bold text-slate-800 block">{page.traffic.toLocaleString()}</span>
                            <span className="text-[10px] text-slate-400 block">visits/mo</span>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Comp B Top pages */}
                  <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm space-y-4">
                    <h3 className="text-sm font-bold text-slate-400 uppercase tracking-wider">Top Performing Landing Pages (Comp B)</h3>
                    <div className="space-y-3">
                      {result.compBMetrics.topPages.map((page, idx) => (
                        <div key={idx} className="p-3 bg-slate-50 border border-slate-100 rounded-xl flex items-center justify-between gap-4">
                          <div className="min-w-0">
                            <span className="text-xs font-bold text-slate-800 truncate block">{page.url}</span>
                            <span className="text-[10px] text-slate-400 block mt-0.5">{page.keywordsCount} ranking terms</span>
                          </div>
                          <div className="text-right shrink-0">
                            <span className="text-xs font-bold text-slate-800 block">{page.traffic.toLocaleString()}</span>
                            <span className="text-[10px] text-slate-400 block">visits/mo</span>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>

              </div>
            )}

            {/* 5. GAP ANALYSIS DASHBOARD TAB */}
            {activeTab === 'gaps' && (
              <div className="space-y-6">
                <div>
                  <h2 className="text-2xl font-extrabold text-slate-900 tracking-tight">Content Gap Intelligence</h2>
                  <p className="text-sm text-slate-500 mt-1">High-value, completely unbuilt opportunities your competitors are already ranking for</p>
                </div>

                {/* Gap score breakdown */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm text-center">
                    <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Total Gaps Found</span>
                    <span className="text-2xl font-black text-rose-600 block mt-1">{result.gaps.length} Core Pages</span>
                  </div>
                  <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm text-center">
                    <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Easy-win Opportunities</span>
                    <span className="text-2xl font-black text-emerald-600 block mt-1">3 Tasks</span>
                  </div>
                  <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm text-center">
                    <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Urgent Priority</span>
                    <span className="text-2xl font-black text-amber-500 block mt-1">High Impact</span>
                  </div>
                </div>

                {/* Gaps List Table */}
                <div className="bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden">
                  <div className="p-6 border-b border-slate-100 flex justify-between items-center">
                    <div>
                      <h3 className="font-extrabold text-slate-900 text-base">Identified Organic Topic Gaps & Strategic Recommendations</h3>
                      <p className="text-xs text-slate-500 mt-1">Comprehensive audit of unbuilt search gaps mapped by semantic clusters and keywords</p>
                    </div>
                  </div>

                  <div className="overflow-x-auto">
                    <table className="w-full text-left border-collapse">
                      <thead>
                        <tr className="bg-slate-50 border-b border-slate-200 text-slate-400 text-[10px] uppercase font-bold tracking-wider">
                          <th className="py-4 px-6">Topic Cluster</th>
                          <th className="py-4 px-4">Target Keyword</th>
                          <th className="py-4 px-4">Identified Gap</th>
                          <th className="py-4 px-4">Opportunity & Recommendation</th>
                          <th className="py-4 px-4 text-center">Priority</th>
                          <th className="py-4 px-6 text-right">Action</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100 text-xs">
                        {result.gaps.map((gap) => {
                          const gapKeyword = gap.keyword || gap.title.replace('The Ultimate Guide to ', '').replace('Frequently Asked Questions: ', '').replace('Top Rated ', '');
                          
                          let gapFound = "";
                          let recommendation = "";
                          
                          if (gap.category === "FAQ") {
                            gapFound = "Competitors capture high-volume long-tail search intent via structured rich snippets. Self domain has zero FAQ schema.";
                            recommendation = `Generate a fully optimized FAQ guide targeting "${gapKeyword}" with schema markup.`;
                          } else if (gap.category === "Comparison Page") {
                            gapFound = "High commercial intent comparison traffic is locked by third party affiliate directories. Self website is entirely unlisted.";
                            recommendation = `Produce a comparison landing page with transparent matrices for "${gapKeyword}".`;
                          } else if (gap.category === "Landing Page") {
                            gapFound = "Direct transactional landing page is missing. Competitors rank #1-3 driving organic sales.";
                            recommendation = `Draft a conversion-focused landing page for "${gapKeyword}" to secure transactional traffic.`;
                          } else {
                            gapFound = "Deep informational cluster gap. Competitors maintain 3+ active authority articles; self domain has no indexable pages.";
                            recommendation = `Write an in-depth long-form SEO blog post to anchor the "${gap.parentCluster}" topical cluster.`;
                          }

                          return (
                            <tr key={gap.id} className="hover:bg-slate-50/50 transition">
                              <td className="py-4 px-6">
                                <span className="bg-slate-100 text-slate-800 px-2 py-1 rounded-lg font-extrabold text-[10px] uppercase tracking-wider block w-fit">
                                  {gap.parentCluster}
                                </span>
                                <span className="text-[10px] text-slate-400 block mt-1">Type: <strong>{gap.category}</strong></span>
                              </td>
                              <td className="py-4 px-4 font-bold text-slate-800">
                                {gapKeyword}
                              </td>
                              <td className="py-4 px-4 text-slate-600 max-w-xs leading-relaxed">
                                {gapFound}
                              </td>
                              <td className="py-4 px-4 text-slate-600 max-w-sm leading-relaxed">
                                <span className="font-semibold text-slate-800 block mb-0.5">Recommendation:</span>
                                {recommendation}
                              </td>
                              <td className="py-4 px-4 text-center">
                                <span className={`text-[10px] font-bold px-2.5 py-1 rounded-full border ${
                                  gap.priority === 'high' ? 'bg-red-50 text-red-600 border-red-100' :
                                  gap.priority === 'medium' ? 'bg-amber-50 text-amber-700 border-amber-100' :
                                  'bg-slate-50 text-slate-600 border-slate-100'
                                }`}>
                                  {gap.priority.toUpperCase()}
                                </span>
                              </td>
                              <td className="py-4 px-6 text-right">
                                <button
                                  onClick={() => handleQuickWrite(gap.title, [gapKeyword])}
                                  className="px-3.5 py-2 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold rounded-xl flex items-center gap-1.5 transition cursor-pointer shadow-sm hover:shadow"
                                >
                                  <Sparkles className="h-3.5 w-3.5 text-amber-300" />
                                  <span>Generate Content</span>
                                </button>
                              </td>
                            </tr>
                          );
                        })}
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            )}

            {/* 7. RECOMMENDATIONS DASHBOARD TAB */}
            {activeTab === 'recommendations' && (
              <div className="space-y-6">
                <div>
                  <h2 className="text-2xl font-extrabold text-slate-900 tracking-tight">Structured SEO & Content Roadmap</h2>
                  <p className="text-sm text-slate-500 mt-1">Actionable recommendations sorted by ease of execution and business value</p>
                </div>

                <div className="space-y-4">
                  {result.recommendations.map((rec) => (
                    <div key={rec.id} className="bg-white rounded-2xl border border-slate-200 shadow-sm p-6 space-y-4 hover:border-indigo-500/50 transition">
                      <div className="flex flex-col md:flex-row md:items-start justify-between gap-4">
                        
                        <div className="space-y-1.5 flex-1">
                          <div className="flex items-center gap-2">
                            <span className={`text-[9px] font-bold px-2 py-0.5 rounded-full uppercase tracking-wider ${
                              rec.priority === 'high' ? 'bg-red-50 text-red-600 border border-red-100' :
                              rec.priority === 'medium' ? 'bg-amber-50 text-amber-700 border border-amber-100' :
                              'bg-slate-100 text-slate-600'
                            }`}>
                              {rec.priority} Priority
                            </span>
                            <span className="text-slate-400 text-xs">·</span>
                            <span className="text-xs text-slate-500 font-bold uppercase">
                              Action: {rec.action}
                            </span>
                          </div>

                          <h3 className="text-base font-extrabold text-slate-900">{rec.title}</h3>
                          <p className="text-xs text-slate-500 leading-relaxed max-w-3xl">
                            {rec.reason}
                          </p>
                        </div>

                        {/* Recommendation metadata badges */}
                        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 bg-slate-50 p-4 rounded-xl shrink-0 min-w-full md:min-w-0 md:w-auto">
                          <div className="text-center px-2">
                            <span className="text-[9px] text-slate-400 uppercase font-semibold">Est. Traffic</span>
                            <span className="text-xs font-black text-slate-800 block mt-0.5">+{rec.estimatedTraffic}/mo</span>
                          </div>
                          <div className="text-center px-2 border-l border-slate-200">
                            <span className="text-[9px] text-slate-400 uppercase font-semibold">Difficulty</span>
                            <span className="text-xs font-black text-slate-800 block mt-0.5 capitalize">{rec.difficulty}</span>
                          </div>
                          <div className="text-center px-2 border-l border-slate-200">
                            <span className="text-[9px] text-slate-400 uppercase font-semibold">Effort</span>
                            <span className="text-xs font-black text-slate-800 block mt-0.5">{rec.effort}</span>
                          </div>
                          <div className="text-center px-2 border-l border-slate-200">
                            <span className="text-[9px] text-slate-400 uppercase font-semibold">Confidence</span>
                            <span className="text-xs font-black text-emerald-600 block mt-0.5">{rec.confidence}%</span>
                          </div>
                        </div>

                      </div>

                      {/* Generate trigger block */}
                      <div className="border-t border-slate-100 pt-4 flex justify-end">
                        <button
                          onClick={() => handleQuickWrite(rec.title, [rec.title])}
                          className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs rounded-xl flex items-center gap-1.5 transition cursor-pointer"
                        >
                          <Sparkles className="h-4 w-4" />
                          <span>One-Click "Generate Content"</span>
                        </button>
                      </div>

                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* 8. AI CONTENT STUDIO TAB */}
            {activeTab === 'studio' && (
              <div className="space-y-6">
                <div>
                  <h2 className="text-2xl font-extrabold text-slate-900 tracking-tight">AI Content Production Studio</h2>
                  <p className="text-sm text-slate-500 mt-1">Deploy search-optimized SEO blogs, custom landing pages, and structured schema markup</p>
                </div>

                {/* Sub toggle for write vs enhance */}
                <div className="flex border-b border-slate-200">
                  <button
                    onClick={() => setStudioMode('create')}
                    className={`pb-3 text-sm font-bold px-6 border-b-2 transition ${
                      studioMode === 'create' ? 'border-indigo-600 text-indigo-700' : 'border-transparent text-slate-500 hover:text-slate-700'
                    }`}
                  >
                    Generate From Scratch
                  </button>
                  <button
                    onClick={() => setStudioMode('enhance')}
                    className={`pb-3 text-sm font-bold px-6 border-b-2 transition ${
                      studioMode === 'enhance' ? 'border-indigo-600 text-indigo-700' : 'border-transparent text-slate-500 hover:text-slate-700'
                    }`}
                  >
                    Enhance & Audit Existing Content
                  </button>
                </div>

                {studioMode === 'create' ? (
                  // WRITE FROM SCRATCH FLOW
                  <div className="grid grid-cols-1 lg:grid-cols-5 gap-6">
                    {/* Input Configurations column */}
                    <form onSubmit={handleGenerateContent} className="lg:col-span-2 bg-white p-6 rounded-3xl border border-slate-200 shadow-sm space-y-4">
                      <h3 className="text-sm font-extrabold text-slate-900 uppercase tracking-wider">SEO Parameters</h3>

                      {/* Topic title */}
                      <div className="space-y-1.5">
                        <label className="text-xs font-bold text-slate-700 block">Topic / Working Title</label>
                        <input
                          type="text"
                          required
                          placeholder="e.g., Ultimate Guide to Subscription Billing Solutions"
                          value={genTopic}
                          onChange={(e) => setGenTopic(e.target.value)}
                          className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-2.5 text-xs outline-none focus:bg-white focus:ring-2 focus:ring-indigo-500/20"
                        />
                      </div>

                      {/* Type of Content */}
                      <div className="space-y-1.5">
                        <label className="text-xs font-bold text-slate-700 block">Content Asset Type</label>
                        <select
                          value={genType}
                          onChange={(e: any) => setGenType(e.target.value)}
                          className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-2.5 text-xs font-semibold text-slate-700 outline-none"
                        >
                          <option value="Blog">SEO Long-form Blog</option>
                          <option value="Landing Page">Optimized Product Landing Page</option>
                          <option value="FAQ">Structured FAQ Page</option>
                          <option value="Comparison Page">Transparant Competitor Comparison Sheet</option>
                          <option value="Product Description">Rich Product Description</option>
                        </select>
                      </div>

                      {/* Targeted Keywords tag-manager */}
                      <div className="space-y-1.5">
                        <label className="text-xs font-bold text-slate-700 block">Focus Keywords to Integrate</label>
                        <div className="flex gap-2">
                          <input
                            type="text"
                            placeholder="Add keyword..."
                            value={newKeywordInput}
                            onChange={(e) => setNewKeywordInput(e.target.value)}
                            onKeyDown={(e) => e.key === 'Enter' && (e.preventDefault(), handleAddKeyword())}
                            className="flex-1 bg-slate-50 border border-slate-200 rounded-xl px-4 py-2 text-xs outline-none focus:bg-white focus:ring-2 focus:ring-indigo-500/20"
                          />
                          <button
                            type="button"
                            onClick={handleAddKeyword}
                            className="px-3 bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold rounded-xl text-xs transition cursor-pointer"
                          >
                            Add
                          </button>
                        </div>

                        {/* Keywords Pills box */}
                        {genKeywords.length > 0 && (
                          <div className="flex flex-wrap gap-1.5 mt-2">
                            {genKeywords.map((kw, i) => (
                              <span key={i} className="bg-indigo-50 border border-indigo-100 text-indigo-700 text-[10px] font-bold px-2 py-0.5 rounded-lg flex items-center gap-1">
                                {kw}
                                <button type="button" onClick={() => handleRemoveKeyword(i)} className="text-rose-500 hover:underline">×</button>
                              </span>
                            ))}
                          </div>
                        )}
                      </div>

                      {/* Desired tone of voice */}
                      <div className="space-y-1.5">
                        <label className="text-xs font-bold text-slate-700 block">Tone of Voice</label>
                        <select
                          value={genTone}
                          onChange={(e) => setGenTone(e.target.value)}
                          className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-2.5 text-xs font-semibold text-slate-700 outline-none"
                        >
                          <option value="Professional & Authoritative">Professional & Authoritative (Recommended)</option>
                          <option value="Conversational & Engaging">Conversational & Engaging</option>
                          <option value="Highly Technical / Engineer-Focused">Highly Technical / Engineer-Focused</option>
                          <option value="Minimalist & Product-Led">Minimalist & Product-Led</option>
                        </select>
                      </div>

                      {/* Additional Instructions */}
                      <div className="space-y-1.5">
                        <label className="text-xs font-bold text-slate-700 block">Custom Prompts or Outline Instructions</label>
                        <textarea
                          rows={3}
                          placeholder="e.g., Include a clean comparison table comparing standard pricing modules..."
                          value={genInstructions}
                          onChange={(e) => setGenInstructions(e.target.value)}
                          className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-2 text-xs outline-none focus:bg-white focus:ring-2 focus:ring-indigo-500/20"
                        />
                      </div>

                      <button
                        type="submit"
                        disabled={isGenerating}
                        className="w-full py-3 bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded-2xl shadow-lg flex items-center justify-center gap-2 transition disabled:bg-slate-300 disabled:cursor-not-allowed cursor-pointer"
                      >
                        {isGenerating ? (
                          <>
                            <RefreshCw className="h-4.5 w-4.5 animate-spin" />
                            <span>AI Studio generating complete document...</span>
                          </>
                        ) : (
                          <>
                            <Sparkles className="h-4.5 w-4.5 text-amber-300" />
                            <span className="text-xs">Draft Optimized Content Draft</span>
                          </>
                        )}
                      </button>
                    </form>

                    {/* Output Preview Column */}
                    <div className="lg:col-span-3 space-y-4">
                      {genResult ? (
                        <div className="bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden flex flex-col h-[600px]">
                          {/* Tabs for Metadata, Markdown, Schema, Social */}
                          <div className="bg-slate-50 border-b border-slate-200 p-4 flex justify-between items-center flex-wrap gap-2">
                            <div>
                              <span className="text-[10px] font-extrabold text-indigo-600 uppercase block">Asset Completed</span>
                              <h4 className="text-xs font-extrabold text-slate-800 truncate max-w-[200px] md:max-w-md">{genResult.title}</h4>
                            </div>
                            
                            <div className="flex gap-2">
                              <button
                                onClick={() => handleCopyToClipboard(genResult.content, 'Content markdown')}
                                className="p-2 bg-white hover:bg-slate-100 rounded-xl border border-slate-200 text-xs font-bold text-slate-700 flex items-center gap-1 transition cursor-pointer"
                              >
                                <Copy className="h-3.5 w-3.5" />
                                <span>Copy Markdown</span>
                              </button>
                            </div>
                          </div>

                          {/* SEO Metadata cards block */}
                          <div className="p-5 border-b border-slate-100 bg-indigo-50/20 grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
                            <div className="space-y-1">
                              <span className="text-[9px] font-black text-indigo-600 uppercase">Optimized SEO Title</span>
                              <p className="font-bold text-slate-800 leading-normal">{genResult.metaTitle}</p>
                            </div>
                            <div className="space-y-1 border-t md:border-t-0 md:border-l border-indigo-100/60 md:pl-4">
                              <span className="text-[9px] font-black text-indigo-600 uppercase">Optimized Meta Description</span>
                              <p className="text-slate-500 leading-relaxed text-[11px]">{genResult.metaDescription}</p>
                            </div>
                          </div>

                          {/* Markdown scroll viewer */}
                          <div className="flex-1 p-6 overflow-y-auto bg-white prose prose-slate max-w-none text-slate-800 text-xs space-y-4 leading-relaxed">
                            <pre className="whitespace-pre-wrap font-sans select-text border border-slate-100 p-4 rounded-xl bg-slate-50">
                              {genResult.content}
                            </pre>

                            {/* Schema Markup Preview section */}
                            <div className="mt-8 border-t border-slate-200 pt-6">
                              <span className="text-[10px] font-extrabold text-amber-600 uppercase tracking-widest block">Injected FAQ/Article Schema Markup (JSON-LD)</span>
                              <p className="text-[10px] text-slate-400 mt-1">Search bots parse this structured JSON to display rich snippets and list stars.</p>
                              <pre className="bg-slate-900 text-slate-300 text-[10px] p-4 rounded-xl font-mono mt-3 overflow-x-auto">
                                {genResult.schemaMarkup}
                              </pre>
                            </div>

                            {/* Suggested Social shares */}
                            <div className="mt-8 border-t border-slate-200 pt-6 space-y-4">
                              <span className="text-[10px] font-extrabold text-indigo-600 uppercase tracking-widest block">Suggested Social Network Snippets</span>
                              
                              <div className="bg-slate-50 border border-slate-100 p-4 rounded-xl space-y-2">
                                <span className="text-[10px] font-bold text-slate-400 block uppercase">Suggested LinkedIn Share:</span>
                                <p className="text-[11px] text-slate-600 leading-relaxed italic">"{genResult.socialPosts.linkedin}"</p>
                              </div>

                              <div className="bg-slate-50 border border-slate-100 p-4 rounded-xl space-y-2">
                                <span className="text-[10px] font-bold text-slate-400 block uppercase">Suggested X/Twitter Post:</span>
                                <p className="text-[11px] text-slate-600 leading-relaxed italic">"{genResult.socialPosts.twitter}"</p>
                              </div>
                            </div>
                          </div>
                        </div>
                      ) : (
                        <div className="bg-white rounded-3xl border border-slate-200 shadow-sm flex flex-col justify-center items-center py-24 px-6 text-center space-y-4 h-[600px]">
                          <div className="p-4 bg-indigo-50 rounded-2xl text-indigo-600">
                            <Cpu className="w-12 h-12" />
                          </div>
                          <div>
                            <h3 className="font-bold text-slate-900 text-base">Studio Document Sandbox</h3>
                            <p className="text-xs text-slate-400 mt-1 max-w-sm leading-relaxed">
                              Configure your focus keywords, asset type and working title on the left, then click draft to see your customized complete asset.
                            </p>
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                ) : (
                  // AUDIT / ENHANCE EXISTING CONTENT FLOW
                  <div className="grid grid-cols-1 lg:grid-cols-5 gap-6">
                    {/* Input configurations column */}
                    <form onSubmit={handleEnhanceContent} className="lg:col-span-2 bg-white p-6 rounded-3xl border border-slate-200 shadow-sm space-y-4">
                      <h3 className="text-sm font-extrabold text-slate-900 uppercase tracking-wider">Audit Setup</h3>

                      {/* Working URL */}
                      <div className="space-y-1.5">
                        <label className="text-xs font-bold text-slate-700 block">Existing Content URL (Optional)</label>
                        <input
                          type="url"
                          placeholder="https://mywebsite.com/blog/existing-article"
                          value={enhanceUrl}
                          onChange={(e) => setEnhanceUrl(e.target.value)}
                          className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-2.5 text-xs outline-none focus:bg-white focus:ring-2 focus:ring-indigo-500/20"
                        />
                      </div>

                      {/* Content block copy-pasted */}
                      <div className="space-y-1.5">
                        <label className="text-xs font-bold text-slate-700 block">Paste Existing Content text *</label>
                        <textarea
                          rows={14}
                          required
                          placeholder="Paste the raw text of your current webpage/blog draft to detect missing entities, structured schema gaps, headings and missing terms..."
                          value={existingContent}
                          onChange={(e) => setExistingContent(e.target.value)}
                          className="w-full bg-slate-50 border border-slate-200 rounded-xl p-4 text-xs outline-none focus:bg-white focus:ring-2 focus:ring-indigo-500/20 font-mono"
                        />
                      </div>

                      <button
                        type="submit"
                        disabled={isEnhancing}
                        className="w-full py-3 bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded-2xl shadow-lg flex items-center justify-center gap-2 transition disabled:bg-slate-300 disabled:cursor-not-allowed cursor-pointer"
                      >
                        {isEnhancing ? (
                          <>
                            <RefreshCw className="h-4.5 w-4.5 animate-spin" />
                            <span>AI auditor analyzing entity graphs...</span>
                          </>
                        ) : (
                          <>
                            <Activity className="h-4.5 w-4.5" />
                            <span className="text-xs font-extrabold">Run Content Optimization Audit</span>
                          </>
                        )}
                      </button>
                    </form>

                    {/* Output results column */}
                    <div className="lg:col-span-3 space-y-6">
                      {enhanceResult ? (
                        <div className="space-y-6">
                          
                          {/* Audit score cards */}
                          <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm space-y-5">
                            <h3 className="font-bold text-slate-900 text-sm border-b border-slate-100 pb-3">AI SEO Audit Assessment</h3>
                            
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                              <div className="space-y-2">
                                <span className="text-[10px] font-bold text-slate-400 block uppercase">Missing Semantic Headings</span>
                                <div className="space-y-1.5">
                                  {enhanceResult.missingHeadings.map((h, i) => (
                                    <div key={i} className="text-xs font-bold text-rose-700 flex items-start gap-1">
                                      <TrendingDown className="h-3.5 w-3.5 text-rose-500 shrink-0 mt-0.5" />
                                      <span>{h}</span>
                                    </div>
                                  ))}
                                </div>
                              </div>

                              <div className="space-y-2">
                                <span className="text-[10px] font-bold text-slate-400 block uppercase">Suggested Entity Additions</span>
                                <div className="flex flex-wrap gap-1">
                                  {enhanceResult.missingEntities.map((ent, i) => (
                                    <span key={i} className="bg-rose-50 border border-rose-100 text-rose-800 text-[10px] font-semibold px-2 py-0.5 rounded-lg">
                                      {ent}
                                    </span>
                                  ))}
                                </div>
                              </div>
                            </div>

                            {/* Internal Links section */}
                            <div className="border-t border-slate-100 pt-4 space-y-2 text-xs">
                              <span className="text-[10px] font-bold text-indigo-600 block uppercase">Internal Linking Opportunities</span>
                              <div className="space-y-2 mt-1">
                                {enhanceResult.internalLinks.map((link, i) => (
                                  <div key={i} className="p-3 bg-indigo-50/20 border border-indigo-100/30 rounded-xl leading-relaxed">
                                    Link the text <strong>"{link.text}"</strong> to <span className="text-indigo-600 font-bold">{link.suggestedUrl}</span>.
                                    <p className="text-[10px] text-slate-500 mt-1">Context: {link.context}</p>
                                  </div>
                                ))}
                              </div>
                            </div>
                          </div>

                          {/* Refactored enhanced output document */}
                          <div className="bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden flex flex-col h-[500px]">
                            <div className="bg-slate-50 border-b border-slate-200 p-4 flex justify-between items-center">
                              <div>
                                <span className="text-[10px] font-extrabold text-emerald-600 uppercase block">Refactored Enhanced Document</span>
                                <h4 className="text-xs font-extrabold text-slate-800 truncate max-w-sm">{enhanceResult.betterTitle}</h4>
                              </div>
                              <button
                                onClick={() => handleCopyToClipboard(enhanceResult.enhancedContent, 'Enhanced document text')}
                                className="p-2 bg-white hover:bg-slate-100 rounded-xl border border-slate-200 text-xs font-bold text-slate-700 flex items-center gap-1 transition cursor-pointer"
                              >
                                <Copy className="h-3.5 w-3.5" />
                                <span>Copy Enhanced Text</span>
                              </button>
                            </div>

                            <div className="p-4 bg-emerald-50/20 border-b border-emerald-100 text-xs text-emerald-800">
                              <span className="font-bold">Optimized Meta Description:</span> {enhanceResult.betterMetaDescription}
                            </div>

                            <div className="flex-1 p-6 overflow-y-auto font-mono text-xs text-slate-800 whitespace-pre-wrap select-text bg-slate-50/50 leading-relaxed">
                              {enhanceResult.enhancedContent}
                            </div>
                          </div>

                        </div>
                      ) : (
                        <div className="bg-white rounded-3xl border border-slate-200 shadow-sm flex flex-col justify-center items-center py-24 px-6 text-center space-y-4 h-[600px]">
                          <div className="p-4 bg-slate-50 rounded-2xl text-slate-400">
                            <Activity className="w-12 h-12" />
                          </div>
                          <div>
                            <h3 className="font-bold text-slate-900 text-base">Content Optimizer Audit Sandbox</h3>
                            <p className="text-xs text-slate-400 mt-1 max-w-sm leading-relaxed">
                              Paste your existing drafts to identify missing headers, structured question boxes, internal links and see an immediate beautifully rewritten optimized draft.
                            </p>
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                )}

              </div>
            )}

            {/* 9. REPORTS TAB */}
            {activeTab === 'reports' && (
              <div className="space-y-6">
                <div>
                  <h2 className="text-2xl font-extrabold text-slate-900 tracking-tight">Executive Exporter & Weekly Reports</h2>
                  <p className="text-sm text-slate-500 mt-1">Compile and print reports detailing organic visibility and content gap scores</p>
                </div>
 
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {/* Markdown Exporter */}
                  <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm space-y-4">
                    <div className="p-3 bg-slate-50 rounded-2xl text-indigo-600 w-fit">
                      <FileText className="w-8 h-8" />
                    </div>
                    <h3 className="text-base font-extrabold text-slate-900">Download High-Contrast Markdown Report</h3>
                    <p className="text-xs text-slate-500 leading-relaxed">
                      Download a structured Markdown document compiling your domain authority scores, unbuilt keywords, organic ranking visibility and recommended drafts list. Perfect for team meetings or importing into Notion/Slack.
                    </p>
                    <button
                      onClick={() => handleExportReport('MD')}
                      className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 transition cursor-pointer"
                    >
                      <Download className="h-4 w-4" />
                      <span>Download .md Document</span>
                    </button>
                  </div>

                  {/* CSV Exporter */}
                  <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm space-y-4">
                    <div className="p-3 bg-slate-50 rounded-2xl text-emerald-600 w-fit">
                      <Database className="w-8 h-8" />
                    </div>
                    <h3 className="text-base font-extrabold text-slate-900">Export Raw Keyword Gaps (CSV / Excel)</h3>
                    <p className="text-xs text-slate-500 leading-relaxed">
                      Download a spreadsheet listing each semantic search phrase, its parent thematic category, search volume, keyword difficulty score, intent classification, and comparison rankings across domains.
                    </p>
                    <button
                      onClick={() => handleExportReport('CSV')}
                      className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 transition cursor-pointer"
                    >
                      <Download className="h-4 w-4" />
                      <span>Download .csv Spreadsheet</span>
                    </button>
                  </div>
                </div>

                {/* Sub Weekly schedule simulation */}
                <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm space-y-4">
                  <h3 className="text-sm font-bold text-slate-900">Weekly Scheduled Email Alerts (Simulated Schedule)</h3>
                  <div className="flex items-center gap-4 p-4 bg-slate-50 border border-slate-100 rounded-2xl">
                    <CheckSquare className="h-5 w-5 text-indigo-600" />
                    <div>
                      <span className="text-xs font-bold text-slate-800 block">Weekly Digest active</span>
                      <p className="text-[11px] text-slate-400 mt-0.5">We will send automated updates listing newly discovered crawler gap matrices to <strong>{result.selfUrl.replace('https://', '')}</strong> admin team.</p>
                    </div>
                  </div>
                </div>

              </div>
            )}

            {/* 10. ALERTS TAB */}
            {activeTab === 'alerts' && (
              <div className="space-y-6">
                <div>
                  <h2 className="text-2xl font-extrabold text-slate-900 tracking-tight">Active Search Radar alerts</h2>
                  <p className="text-sm text-slate-500 mt-1">Automatic alerts tracking competitor on-page and ranking fluctuations</p>
                </div>

                <div className="space-y-3">
                  {alerts.map((alert) => (
                    <div key={alert.id} className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm flex gap-4 hover:bg-slate-50/50 transition">
                      <div className="shrink-0">
                        {alert.type === 'warning' ? (
                          <div className="p-2 bg-rose-50 text-rose-600 rounded-lg">
                            <TrendingDown className="h-4.5 w-4.5" />
                          </div>
                        ) : alert.type === 'success' ? (
                          <div className="p-2 bg-emerald-50 text-emerald-600 rounded-lg">
                            <TrendingUp className="h-4.5 w-4.5" />
                          </div>
                        ) : (
                          <div className="p-2 bg-blue-50 text-blue-600 rounded-lg">
                            <Activity className="h-4.5 w-4.5" />
                          </div>
                        )}
                      </div>

                      <div className="flex-1 space-y-1">
                        <div className="flex justify-between items-center">
                          <h4 className="text-xs font-bold text-slate-800">{alert.title}</h4>
                          <span className="text-[10px] text-slate-400 font-medium">{alert.time}</span>
                        </div>
                        <p className="text-xs text-slate-500 leading-normal">{alert.desc}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* 11. INTEGRATIONS & SETTINGS TAB */}
            {activeTab === 'settings' && (
              <div className="space-y-6">
                <div>
                  <h2 className="text-2xl font-extrabold text-slate-900 tracking-tight">Integrations & API Settings</h2>
                  <p className="text-sm text-slate-500 mt-1">Configure live crawlers, custom models and export endpoints</p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {/* Keys settings card */}
                  <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm space-y-4">
                    <h3 className="text-sm font-extrabold text-slate-900 uppercase tracking-wider">API Authentication Keys</h3>
                    
                    <div className="space-y-3">
                      <div className="space-y-1.5">
                        <label className="text-xs font-bold text-slate-600 block">Gemini API Key</label>
                        <input
                          type="password"
                          disabled
                          value="••••••••••••••••••••••••••••••••"
                          className="w-full bg-slate-100 border border-slate-200 rounded-xl px-4 py-2 text-xs text-slate-500 outline-none"
                        />
                        <span className="text-[10px] text-slate-400 block mt-0.5">Managed securely via AI Studio secrets panel.</span>
                      </div>

                      <div className="space-y-1.5">
                        <label className="text-xs font-bold text-slate-600 block">DataForSEO API Key</label>
                        <input
                          type="password"
                          disabled
                          value="••••••••••••••••••••"
                          className="w-full bg-slate-100 border border-slate-200 rounded-xl px-4 py-2 text-xs text-slate-500 outline-none"
                        />
                        <span className="text-[10px] text-slate-400 block mt-0.5">Configured inside sandbox container credentials.</span>
                      </div>
                    </div>
                  </div>

                  {/* CMS Destination card */}
                  <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm space-y-4">
                    <h3 className="text-sm font-extrabold text-slate-900 uppercase tracking-wider">Export Destinations</h3>
                    
                    <div className="space-y-3">
                      <div className="flex items-center justify-between p-3 bg-slate-50 border border-slate-100 rounded-xl text-xs">
                        <div className="space-y-0.5">
                          <span className="font-bold text-slate-800 block">WordPress Integration</span>
                          <span className="text-[10px] text-slate-400 block">Deploy directly to wp-json drafts.</span>
                        </div>
                        <span className="bg-slate-200 text-slate-600 text-[9px] font-black px-1.5 py-0.5 rounded-full">INACTIVE</span>
                      </div>

                      <div className="flex items-center justify-between p-3 bg-slate-50 border border-slate-100 rounded-xl text-xs">
                        <div className="space-y-0.5">
                          <span className="font-bold text-slate-800 block">Notion Workspace</span>
                          <span className="text-[10px] text-slate-400 block">Export drafts to page directory.</span>
                        </div>
                        <span className="bg-slate-200 text-slate-600 text-[9px] font-black px-1.5 py-0.5 rounded-full">INACTIVE</span>
                      </div>
                    </div>
                  </div>
                </div>

              </div>
            )}

          </main>
        </div>
      )}
    </div>
  );
}
