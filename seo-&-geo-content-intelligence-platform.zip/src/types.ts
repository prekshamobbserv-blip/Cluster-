export interface ExecutiveOverview {
  organicTrafficSelf: number;
  organicTrafficCompA: number;
  organicTrafficCompB: number;
  totalKeywordsSelf: number;
  totalKeywordsCompA: number;
  totalKeywordsCompB: number;
  rankingKeywordsSelf: number;
  rankingKeywordsCompA: number;
  rankingKeywordsCompB: number;
  contentHealthScore: number;
  topicalAuthorityScore: number; // Semantic/Organic authority score %
  contentGapScore: number;
  seoScore: number;
}

export interface KeywordItem {
  id: string;
  keyword: string;
  cluster: string;
  volume: number;
  difficulty: number; // KD %
  positionSelf: number; // 0 or empty means not ranking / >100
  positionCompA: number;
  positionCompB: number;
  intent: 'Informational' | 'Transactional' | 'Navigational' | 'Commercial';
  trend: 'up' | 'down' | 'stable';
  branded: boolean;
  clicks?: number;       // Google Search Console field
  impressions?: number;  // Google Search Console field
  ctr?: number;          // Google Search Console field
}

export interface TopicCluster {
  id: string;
  name: string;
  description: string;
  keywordsCount: number;
  opportunityScore: number; // %
  keywords: string[];
  status: 'covered' | 'partial' | 'gap';
  articles: string[];
  missingContent: string[];
}

export interface TopPageItem {
  url: string;
  traffic: number;
  keywordsCount: number;
}

export interface CompetitorMetrics {
  domain: string;
  rankingKeywords: number;
  avgPosition: number;
  domainAuthority: number;
  traffic: number;
  topPages: TopPageItem[];
  keywordGrowth: number;
  contentCount: number;
}

export interface ContentGapItem {
  id: string;
  category: 'Missing Page' | 'Blog Topic' | 'Category Page' | 'FAQ' | 'Comparison Page' | 'Case Study' | 'Landing Page';
  title: string;
  keyword?: string;
  searchVolume: number;
  difficulty: number; // %
  priority: 'high' | 'medium' | 'low';
  opportunityScore: number;
  parentCluster: string;
}

export interface RecommendationItem {
  id: string;
  priority: 'high' | 'medium' | 'low';
  action: 'create' | 'update' | 'improve';
  title: string;
  reason: string;
  estimatedTraffic: number;
  difficulty: 'easy' | 'medium' | 'hard';
  effort: string;
  confidence: number; // %
}

export interface AnalysisResponse {
  selfUrl: string;
  competitorA: string;
  competitorB: string;
  timestamp: string;
  overview: ExecutiveOverview;
  keywords: KeywordItem[];
  clusters: TopicCluster[];
  compAMetrics: CompetitorMetrics;
  compBMetrics: CompetitorMetrics;
  gaps: ContentGapItem[];
  recommendations: RecommendationItem[];
}

export interface ContentGenerationRequest {
  topic: string;
  type: 'Blog' | 'Landing Page' | 'FAQ' | 'Comparison Page' | 'Product Description';
  keywords: string[];
  tone: string;
  additionalInstructions?: string;
}

export interface ContentGenerationResponse {
  title: string;
  metaTitle: string;
  metaDescription: string;
  content: string; // Markdown format
  schemaMarkup: string; // JSON-LD
  socialPosts: {
    linkedin: string;
    twitter: string;
  };
}

export interface ContentEnhanceRequest {
  url: string;
  existingContent: string;
}

export interface ContentEnhanceResponse {
  missingHeadings: string[];
  missingEntities: string[];
  missingFAQs: { question: string; answer: string }[];
  missingKeywords: string[];
  internalLinks: { text: string; suggestedUrl: string; context: string }[];
  betterTitle: string;
  betterMetaDescription: string;
  enhancedContent: string; // Enhanced Markdown
}
